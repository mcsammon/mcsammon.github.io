Files should be run in order from 1_, ..., 12_
Required datasets:
1. CRSP: mutual funds, monthly stock 
2. Thompson: S12, 13F
3. Global Fin. Data (GFD): total return indices
4. WRDS: Beta suite, MF links, intraday indicators
5. IBES: consensus estimates and actuals
6. Refinitiv: total return indices

Data is available upon request.
