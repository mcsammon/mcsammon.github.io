#Loop over integers between 1 and 10, with the option to stop at 5
for i in range (1,11):
    print(i)
    if i == 5:
        print("Breakpoint")