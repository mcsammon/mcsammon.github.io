#Loop over integers between 1 and 10
for i in range (1,11):
    print(i)

dogs=['odie','courage','lassie','balto']
for dog in dogs:
    print(dog)

dictionary = {
    'fish': 'Bubbles',
    'dog': 'Spot',
    'cat': 'Frisky',
}
for item in dictionary:
    print(item)
    print(dictionary[item])


x=5
print(x)
name="Marco"
print(name)

import re
result="regulation deregulation dogs cats"
regwords = re.findall(r'\b\w*regulat\w*\b', result, flags=re.IGNORECASE)

print("Unique Words Containing \"regulat\"")
print(set(regwords))