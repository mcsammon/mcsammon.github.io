
import pandas as pd
import numpy as np

cik=1
filedate="01102018"
formtype="10k"
regwords=10
words=100

#pd.options.mode.chained_assignment = None  # default='warn'

addframe = pd.DataFrame(np.zeros((2, 5)))
addframe.columns = ['cik', 'filedate', 'formtype', 'regwords', 'words']
print(addframe)
addframe.loc[0,'cik']=cik
addframe.loc[0,'filedate'] =filedate
addframe.loc[0,'formtype'] =formtype
addframe.loc[0,'regwords'] =regwords
addframe.loc[0,'words'] =words
print(addframe)