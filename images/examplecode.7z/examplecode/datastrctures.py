import collections
dict_x = collections.defaultdict(list)
dict_x['Style'].append("Pepperoni")
dict_x['Number'].append(2)
dict_x['Style'].append("Plain Cheese")
dict_x['Number'].append(3)

import pickle
pickle.dump(dict_x, open('dictsave', 'wb'))
newdict = pickle.load(open('dictsave', 'rb'))