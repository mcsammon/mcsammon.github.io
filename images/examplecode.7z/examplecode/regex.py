import re

test="101000000000100"
#* is greedy, match 0 or more
#*? is reluctant, match zero or 1 (and no more)
t2=re.findall("1.*1",test)
print(t2)
t3=re.findall("1.*?1",test)
print(t3)

# using finditer to count words
string="better ingredients, better pizza, papa john's pizza"
nummatch = sum(1 for _ in re.finditer(r'\bpizza\b',
                                      string, flags=re.IGNORECASE))
print(nummatch)
