dogs=['odie','courage','lassie','balto']
isdog="garfield"
if isdog in dogs:
    print(isdog," is a dog")
else:
    print(isdog," is not a dog")