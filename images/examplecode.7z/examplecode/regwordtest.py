import re

result="deregulate deregulation regulation regulate regulat regular pizza pizza pizza"

#\b - word boundary (a word is a sequence of word characters)
#\w - word characters, usually [a-zA-Z0-9_]
#* - match 0 or more of the preceding expression
#This finds any word containing "regulat"
regwords = re.findall(r'\b\w*regulat\w*\b', result, flags=re.IGNORECASE)

print(regwords)
print(len(regwords))

pizzawords = sum(1 for _ in re.finditer(r'\s%s.\s' % re.escape('pizz'), result, flags=re.IGNORECASE))

print(pizzawords)
