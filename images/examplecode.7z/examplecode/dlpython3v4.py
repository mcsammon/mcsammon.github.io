#tried the two pass
from bs4 import BeautifulSoup
import os
import re
import codecs

import EDGAR_Pac_v3 as EDGAR_Pac
import EDGAR_Forms_v2 as  EDGAR_Forms # This module contains some predefined form groups
import General_Utilities_v2 as General_Utilities

# List target forms as strings separated by commas (case sensitive) or
#   load from EDGAR_Forms.  (See EDGAR_Forms module for predefined lists.)

#This is just 10-K's
PARM_FORMS = EDGAR_Forms.f_10X3

regexTxt = 'item[^a-zA-Z\n]*1a\..*?item[^a-zA-Z\n]*1b'
regexTxt2 = 'item[^a-zA-Z\n]*1a\..*?item[^a-zA^Z\n]*2'

regexTxtEx = 'item[^a-zA-Z\n]*1a.*?item[^a-zA^Z\n]*1b'
regexTxtEx2 = 'item[^a-zA-Z\n]*1a.*?item[^a-zA^Z\n]*2'
paser = 'html.parser'
# paser = 'html5lib'
max_attempt = 3

if not os.path.exists('./testfiles2/'):
   os.makedirs('./testfiles2/')

# EDGAR parameter
PARM_EDGARPREFIX = 'https://www.sec.gov/Archives/'
PARM_LOGFILE = (r'testlog.txt')

#Risk factors started in 2006
start_year=2006 # change back to 2006 later
end_year=2010
dllimit=5

#keep track of total number of forms, and total number of errors
n_tot = 0
n_errs = 0
#Keep a log of the errors
f_log = open(PARM_LOGFILE, 'a')

# range is not inclusive
for year in range(start_year,end_year+1):
   if not os.path.exists('./testfiles2/' + str(year) + '/'):
      os.makedirs('./testfiles2/' + str(year) + '/')
   path = './testfiles2/' + str(year) + '/'
   for q in range(1,5):
      #number for that quarter
      n_qtr = 0
      file_count = {}
      print('Year ' + str(year) + ' quarter ' + str(q))
      #Use a different way to access the master index file
      masterindex = EDGAR_Pac.download_masterindex(year, q, True)
      dlcount=0
      for item in masterindex:
          #print(item)
          #while EDGAR_Pac.edgar_server_not_available(True):  # kill time when server not available
          #   pass
          #Check if it is a 10-K
          if item.form in PARM_FORMS:
              n_qtr += 1
              # Keep track of filings and identify duplicates
              fid = str(item.cik) + str(item.filingdate) + item.form
              if fid in file_count:
                  file_count[fid] += 1
              else:
                  file_count[fid] = 1
              # Setup EDGAR URL and output file name
              url = PARM_EDGARPREFIX + item.path
              fname = (path + str(item.filingdate) + '_' + item.form.replace('/', '-') + '_' +
                       item.path.replace('/', '_'))
              fname = fname.replace('.txt', '_' + str(file_count[fid]) + '.txt')
              ftext = General_Utilities.download_to_doc(url, f_log)
              if ftext==None:
                  n_errs += 1
              else:
                  dlcount += 1
              n_tot += 1
              #Tested -- this works, now want to avoid saving the file

              #Read the file
              if ftext!=None:
                  output = './testfiles2/' + str(year) + '/' + str(item.cik) \
                           + '-' + str(item.filingdate) + '-' + item.form + '.txt'
                  # check if the file is already there
                  # to satisfy, must both be there, and have size > 0
                  file_exist = os.path.isfile(output) and os.path.getsize(output) > 0
                  if not file_exist:
                      if '<html>' in ftext.lower():
                          try:
                              ftext = BeautifulSoup(ftext,paser).get_text()
                          except Exception as e:
                              print(str(e))
                              continue
                      section = re.findall('item[^a-zA-Z\n]*1a\.',ftext, re.IGNORECASE | re.DOTALL)
                      if len(section) == 0:
                          section = re.findall(regexTxtEx,ftext, re.IGNORECASE | re.DOTALL)
                          if len(section) == 0:
                              section = re.findall(regexTxtEx2,ftext, re.IGNORECASE | re.DOTALL)
                      else:
                          section = re.findall(regexTxt,ftext, re.IGNORECASE | re.DOTALL)
                          if len(section) == 0:
                              section = re.findall(regexTxt2,ftext, re.IGNORECASE | re.DOTALL)
                      #print('find ' + str(len(section)) + ' instance(s) of item 1A')
                      if len(section) == 0:
                          with open(output, 'w') as g:
                              g.write('')
                      else:
                          result = max(section,key=len)
                          with codecs.open(output, 'w', 'utf-8') as g:
                              #Remove extra spaces and table of contents
                              result = re.sub(r'table of contents', ' ', result, flags=re.IGNORECASE)
                              result = result.strip()
                              result = re.sub('\s+', ' ', result).strip()
                              g.write(result)
                              g.close()

                  if dlcount==dllimit:
                      break

print('Risk Factors Download Complete')
