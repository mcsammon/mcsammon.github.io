import re
#String
ftext="item1a. section to extract item1b section to ignore"
#What to find
regexTxt = 'item[^a-zA-Z\n]*1a\..*?item[^a-zA-Z\n]*1b'
#Note, this will include both "bookends"
section = re.findall(regexTxt, ftext, re.IGNORECASE | re.DOTALL)
#re.findall returns a list -- this converts it to a string
section=section[0]
#Remove the bookends with re.sub
section = re.sub('item[^a-zA-Z\n]*1a\.',"",section,flags=re.IGNORECASE)
section = re.sub('item[^a-zA-Z\n]*1b',"",section,flags=re.IGNORECASE)
print(section)
