from temp import testfun

print(testfun(5,3))