import re
string="I buy pizza ingredients. My dog likes bones. " \
       "Pizza is still unregulated. Dog bones are heavily regulated."
sents=string.split(".")
#When splitting this way, last element will be empty - remove
del sents[-1]
print(sents)
sentcount=0
regcount=0
for sent in sents:
    sentcount=sentcount+1
    regwords = re.findall(r'\b\w*regulat\w*\b', sent, flags=re.IGNORECASE)
    if len(regwords)>0:
        regcount=regcount+1
print("Num sents: ",sentcount," Num reg sents: ",regcount)