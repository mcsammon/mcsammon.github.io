def testfun(a,b):
    return a+b