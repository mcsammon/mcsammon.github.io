#Import Python Packages
from bs4 import BeautifulSoup
import re
import codecs

#Regular expressions we will use to identify the risk factors section
#The risk factors section is item 1a, so we want to identify the section
#between item1a and item 1b, or item1a and item 2
regexTxt = 'item[^a-zA-Z\n]*1a\..*?item[^a-zA-Z\n]*1b'
regexTxt2 = 'item[^a-zA-Z\n]*1a\..*?item[^a-zA^Z\n]*2'
regexTxtEx = 'item[^a-zA-Z\n]*1a.*?item[^a-zA^Z\n]*1b'
regexTxtEx2 = 'item[^a-zA-Z\n]*1a.*?item[^a-zA^Z\n]*2'
#Set parset for beautiful soup
paser = 'html.parser'
# paser = 'html5lib'

#Read the  20090926 10K for AAPL
with codecs.open('apple10k.txt', 'r', encoding='utf8', errors='replace') as myfile:
    ftext = myfile.read().replace('\n', ' ')

#Use beautiful soup to clean the file if it is html
if '<html>' in ftext.lower():
  try:
      ftext = BeautifulSoup(ftext,paser).get_text()
  except Exception as e:
      print(str(e))
#first pass at identifying the risk factors section
section = re.findall('item[^a-zA-Z\n]*1a\.',ftext, re.IGNORECASE | re.DOTALL)
#If that fails, try alternative 1
if len(section) == 0:
  section = re.findall(regexTxtEx,ftext, re.IGNORECASE | re.DOTALL)
  #If alternative 1 fails, try alternative 2
  if len(section) == 0:
      section = re.findall(regexTxtEx2,ftext, re.IGNORECASE | re.DOTALL)
#If it succeeds, extract the risk factors section
else:
  section = re.findall(regexTxt,ftext, re.IGNORECASE | re.DOTALL)
  if len(section) == 0:
      section = re.findall(regexTxt2,ftext, re.IGNORECASE | re.DOTALL)
#Sometimes there will be multiple matches
#A common case is one match in the table of contents, and one match
#in the body of the document.
#Taking the longer section avoids the mistaken match to the
#table of contents.
#print('find ' + str(len(section)) + ' instance(s) of item 1A')
result = max(section,key=len)

#Remove extra spaces and string "table of contents", which may appear
#on every page
result = re.sub(r'table of contents', ' ', result, flags=re.IGNORECASE)
result = result.strip()
result = re.sub('\s+', ' ', result).strip()

#Write risk factors section to a text file
with codecs.open('aaplrf.txt', 'w', 'utf-8') as g:
    g.write(result)
    g.close()

#\b - word boundary (a word is a sequence of word characters)
#\w - word characters, usually [a-zA-Z0-9_]
#* - match 0 or more of the preceding expression
#This finds any word containing "regulat"
regwords = re.findall(r'\b\w*regulat\w*\b', result, flags=re.IGNORECASE)

print("Unique Words Containing \"regulat\"")
print(set(regwords))
print("Number of Words Containing \"regulat\": ",len(regwords))

wordcount = len(result.split())
print("Total Number of Words: ",wordcount)
