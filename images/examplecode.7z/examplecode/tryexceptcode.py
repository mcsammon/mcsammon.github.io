def fun1(a):
    return a*5

def fun2(a):
    return a/5

list=[10,"a"]
for item in list:
    #multiplication works on strings!
    print(fun1(item))

for item in list:
    #division does not
    try:
        print(fun2(item))
    except:
        print("Not a number")