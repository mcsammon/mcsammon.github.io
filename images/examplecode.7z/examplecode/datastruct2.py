#Loads dictionary
import pickle
newdict = pickle.load(open('dictsave', 'rb'))
print(newdict['Style'])
print(newdict["Papa John"])