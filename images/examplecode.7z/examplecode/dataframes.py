
import pandas as pd
import numpy as np
n=3
m=3
df=pd.DataFrame(np.zeros((n,m)))
print(df)

cik=1
filedate="01102018"
formtype="10k"
regwords=10
words=100

addframe = pd.DataFrame(np.zeros((1, 5)))
addframe.columns = ['cik', 'filedate', 'formtype', 'regwords', 'words']
addframe['cik']=cik
addframe['filedate'] =filedate
addframe['formtype'] =formtype
addframe['regwords'] =regwords
addframe['words'] =words

outputdf= pd.DataFrame()
year=3
i=2

print(outputdf)
outputdf = outputdf.append(addframe)
print(outputdf)

t1 = r'tempfiles\savedata' + str(year) + 'p' + str(i) + '.csv'
outputdf.to_csv(t1)
