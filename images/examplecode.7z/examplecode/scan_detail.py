import os, csv, re, string
import nltk
import codecs
nltk.download('punkt')
#Now updated for Python 3.X
#Changed to reflect string write vs. binary write
#And change to SEC filenames

def read_term_structure(term_file):
    terms_full = []
    with open(term_file) as inputfile:
        terms_full = [(cat.strip().split(': ')[0].strip(),[top.split(', ') for top in cat.strip().split(': ')[1].replace('{','').rstrip('}').split('}, ')]) for cat in inputfile]
    for (cat_name,cat) in terms_full:
        if cat_name == 'Fiscal Policy':
            append_list = [top for (cp_name,cp) in terms_full if cp_name in ['Taxes', 'Government Spending, Deficits and Debt', 'Entitlement and Welfare Programs'] for top in cp]
            cat += append_list
        if cat_name == 'Regulation':
            append_list = [top for (cp_name,cp) in terms_full if cp_name in ['Financial Regulation', 'Competition policy', 'Intellectual property policy', 'Labor regulations', 'Immigration', 'Energy and environmental regulation', 'Lawsuit and tort reform, Supreme Court Decisions', 'Housing and Land Management', 'Other regulation'] for top in cp]
            cat += append_list
            
    p = nltk.PorterStemmer()
    terms_stem = []
    terms = []

    for (cat_name,cat) in terms_full:
        cat_terms_stem = []
        cat_terms = []
        for top in cat:
            top_terms_stem = []
            top_terms = []
            for t in top:
                t_stem = ' '.join([p.stem(w) for w in t.split()]).lower().replace('-',' ')
                if t_stem not in top_terms_stem:
                    top_terms_stem.append(t_stem)
                    top_terms.append(t.strip())
            cat_terms_stem.append(top_terms_stem)
            cat_terms.append(top_terms)
        terms_stem.append((cat_name,cat_terms_stem))
        terms.append((cat_name,cat_terms))
    return terms_stem,terms

term_file = 'terms_v3.txt'
terms_stem,terms = read_term_structure(term_file)

def flatten(t_list):
    return [t for cat in t_list for top in cat[1] for t in top]
flat_terms = flatten(terms)
flat_terms_stem = flatten(terms_stem)

def find_topic(t_list):
    return [top[0].upper() for cat in t_list for top in cat[1]]

def find_narrow_terms(t_stem,t):
    global flat_terms_stem,flat_terms
    # has_term = [(tp_stem,tp) for (tp_stem,tp) in zip(flat_terms_stem,flat_terms) if tp_stem != t_stem]
    has_term = [(tp_stem,tp) for (tp_stem,tp) in zip(flat_terms_stem,flat_terms) if re.search(r'\b{0}\b'.format(t_stem), tp_stem) and tp_stem != t_stem]
    # if len(has_term)>1:
        # print t + " is also in: "
        # print [tp for (tp_stem,tp) in set(has_term)]
    return(set(has_term))

#for (t_stem,t) in zip(flat_terms_stem,flat_terms):
    #print t + " is also in: "
    #print [tp for (tp_stem,tp) in find_narrow_terms(t_stem,t)]
    
# raise SystemExit
#I changed this to reflect the new filenames from the SEC
#OLD
#cik = fn.split('-')[0]
#year_file = fn.split('-')[1]
#month_file = fn.split('-')[2]
#date_file = fn.split('-')[3]
#file_name = fn.split('-', 4)[4]
#headers = ['CIK number', 'Year filed', 'Month filed', 'Date filed', 'Filename', '# Sentences']
#NEW
#cik = fn.split('-')[0]
#date_file = fn.split('-')[1]
#file_nametemp = fn.split('-')[2]
#file_name=file_nametemp.split('.')[0]
#Match removal of year and month
headers = ['CIK number', 'Date filed', 'Form Type', '# Sentences']

nzero = len(headers)
headers = headers + flat_terms + ['Raw: ' + t for t in find_topic(terms)] + ['Adj: ' + t for t in find_topic(terms)]
nzero = len(headers) - nzero + 1

#Headers is a list of strings
#note, ab stands for BINARY which does not work in python 3
#with open('firmdata_lable.csv','ab') as fd:
with open('firmdata_lable.csv','w') as fd:
        w = csv.writer(fd)
        w.writerow(headers)

subdirectory = "sentences"
try:
    os.mkdir(subdirectory)
except Exception:
    pass

def count_terms(c):
    rlist = []
    sentences = nltk.sent_tokenize(c)
    p = nltk.PorterStemmer()    
    if sentences:
        rlist.append(str(len(sentences)))
        sentences = [' '.join([w for w in s.split()]) for s in sentences]
        sentences_stem = [' '.join([p.stem(w) for w in s.split()]).lower().replace('taxat','tax').replace('-',' ').replace('farmworker','farm worker').replace('guestworker','guest worker') for s in sentences]
        ## count sentences with certain term (raw count)
        for (t_stem,t)  in zip(flat_terms_stem,flat_terms):
            has_term = [s for s_id, s in enumerate(sentences) if re.search(r'\b{0}\b'.format(t_stem), sentences_stem[s_id])]
            rlist.append(str(len(has_term)))
            if has_term:
                #with open (os.path.join(subdirectory, t.replace("/", "-") + '.txt'),'ab') as sf:
                #subdirectory is always sentences
                #print(subdirectory)
                #t is the term - what the word is being added to
                #replace changes slashes to hyphens to prevent directory issues
                print(t)
                #this opens sentences/[term].txt)
                #this is because os.path.join puts together pieces of a path
                #https://docs.python.org/3.6/library/os.path.html
                #There is something strange going on - b/c error is not in same
                #directory every time.  May be a read/write speed error
                #sleep(0.1) #time in seconds
                with codecs.open(os.path.join(subdirectory, t.replace("/", "-") + '.txt'), 'w','utf-8') as sf:
                    for s in has_term:
                        sf.write("%s\n" % s)
        ## count sentences with certain topic (raw count)
        for (cat_stem, cat) in zip(terms_stem,terms):
            for (top_stem, top) in zip(cat_stem[1],cat[1]):
                has_topic = [s for s_id, s in enumerate(sentences) if any([re.search(r'\b{0}\b'.format(t_stem), sentences_stem[s_id]) for (t_stem,t) in zip(top_stem,top)])]
                rlist.append(str(len(has_topic)))
        ## count sentences with certain topic (adjusted count)
        for (cat_stem, cat) in zip(terms_stem,terms):
            for (top_stem, top) in zip(cat_stem[1],cat[1]):
                has_topic = [s for s_id, s in enumerate(sentences) if any([re.search(r'\b{0}\b'.format(t_stem), sentences_stem[s_id]) and all([not re.search(r'\b{0}\b'.format(tp_stem), sentences_stem[s_id]) for (tp_stem,tp) in find_narrow_terms(t_stem,t)]) for (t_stem,t) in zip(top_stem,top)])]
                rlist.append(str(len(has_topic)))
    else:
        rlist = [0] * nzero
    return rlist

years = range(2006,2016) # change back to 2006 later

for year_index, year in enumerate(years):
    #print 'Working on year ' + str(year)
    #with open('firmdata' + str(year) + '.csv','ab') as fd:
    with open('firmdata' + str(year) + '.csv', 'w') as fd:
        w = csv.writer(fd)
        w.writerow(headers)
        filenames = os.listdir('./files/' + str(year))
        for fn_index, fn in enumerate(filenames):
            # print fn
            with codecs.open('./files/' + str(year) + '/' + fn, 'r','utf-8') as f:
                contents = f.read()


                # This has to be changed, because of the way the data is delivered from the SEC
                #Recall
                # + str(item.cik) + '-' + str(item.filingdate) + '-' + item.form + '.txt'
                #This takes the 3 elements and puts them in the first 3 columns
                cik = fn.split('-')[0]
                date_file = fn.split('-')[1]
                file_nametemp = fn.split('-')[2]
                file_name=file_nametemp.split('.')[0]
                #Deal with the hyphen problem
                file_name=file_name+"-K"
                dataline = [cik, date_file, file_name]
                dataline.extend(count_terms(contents))
                w.writerow(dataline)
print("Counts Completed")
