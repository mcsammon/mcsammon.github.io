function [sigbaridio,sigbarsys,lams] = calclamssym(sign,rho,sigidio,...
    xbaridio,xbarsys,sigx,infshare,kcons,infidio,infsys)
    %% easier fix
    infidio=infidio+kcons;
    infsys=infsys+kcons;
    
    %find elements of  \Sigma bar (point 4 of A.1)
    sigbaridio=((1/sigidio)+infshare*infidio+...
        ((infshare*infidio)^2)/((rho^2)*sigx))^(-1); 
    sigbarsys=((1/sign)+infshare*infsys+...
        ((infshare*infsys)^2)/((rho^2)*sigx))^(-1);
    %Calculate lambdas
    %paren variables are terms inside brackets in (14)
    parenidio=1+((rho^2)*sigx+infshare*infidio)*sigbaridio;
    lambdaidio=sigbaridio*(parenidio)+(rho^2)*(xbaridio^2)*(sigbaridio^2);
    
    parensys=1+((rho^2)*sigx+infshare*infsys)*sigbarsys;
    lambdasys=sigbarsys*(parensys)+(rho^2)*(xbarsys^2)*(sigbarsys^2);
    %Put lambdas into a vector to check ordering
    lams=[lambdaidio,lambdasys];
    
end

