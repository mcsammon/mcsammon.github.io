%% info=[infidio infsys];
function [alteu] = testfnsym(infshare,info,rho,sigx,sign,sigidio,...
    xbaridio,xbarsys,kcons,numsim,musys,muidio,r,informed,Wzero,numksteps,...
    K,devsim,numinv,devinfos,numidio)
        %{
        info 
        devinfos
        %}
        %% program 3, master run sim
        [pms,postpres,postpresdeva,pmsdeva,pmsun,postpresun,...
    profits3,gout,ncmat,ovecnew] = ...
    masterrunsim4(numsim,sigidio,sign,sigx,infshare,...
            info,rho,musys,muidio,xbaridio,xbarsys,...
            r,informed,Wzero,numksteps,K,devsim,kcons,numinv,devinfos,...
            numidio);
            
        %% program 4, calculate deviation utility
        [actual,alt]=finaleu4(pms,postpres,r,Wzero,info,...
            postpresdeva,pmsdeva,devinfos);
        %4th post is veldkamp, 5th pos is admati
        %alt=[altinfo' eui2 euiadmat lams]
        
        %alteu=alt(3);
        %% New method
        alteu=ovecnew(5); 
        %add in uninformed
        v=cov(pmsun);%calculate vcv of posterior means
        t1=postpresun*v;t2=0.5*trace(t1);
        mp=mean(pmsun);
        t3=0.5*mp*postpresun*mp';
        euiun=r*Wzero+t2+t3;%ex-ante expected utility 
        %test
        %{
        alteu
        actual(3)
        euiun
        %}

end

