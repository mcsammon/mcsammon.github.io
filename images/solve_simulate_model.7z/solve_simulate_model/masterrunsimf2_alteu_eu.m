%info=[infidio infsys];
function [ovecnew] = ...
    masterrunsimf2_alteu_eu(numsim,sigidio,sign,sigx,infshare,...
            info,rho,musys,muidio,xbaridio,xbarsys,...
            r,informed,Wzero,numksteps,K,devsim,kcons,numinv,devinfos,...
            numidio,Gamma)
    
    altinfo=devinfos;
    %new utility calc
    %{
    utilitiesinfdev=zeros(numsim*informed,1);  
    profitsinfdev=zeros(numsim*informed,1);    
    %}
    %%fix this number
    infn=10000;
    objfn=zeros(numsim*infn,1);
    objsb=zeros(numsim*infn,2);
    for zz=1:numsim  
 
        rng(zz)%Fix RNG across sims, can test turning off shocks below
        [z,x] = drawshocks2(sigidio,sign,sigx,numidio);

        %zz %display simnum
           
        [profitinddev,objs] = ...
            runsimfastf2_alteu(sigidio,sign,sigx,infshare,...
            info,rho,musys,muidio,xbaridio,xbarsys,...
            r,informed,Wzero,numksteps,K,devsim,kcons,z,x,zz,altinfo,...
            numidio,Gamma);
        
        %new save profits/utilities     
        %}
        
        index1=1+(zz-1)*infn;
        index2=zz*infn;           
        objsb(index1:index2,:)=objs;
        b=-exp(-rho*(profitinddev));
        objfn(index1:index2,:)=b;        
    end %end of simulation loop
    %{
    b=mean(profitsinfdev);
    e=mean(utilitiesinfdev);
    h=rho*mean(profitinddev)-((rho^2)/2)*var(profitinddev);
    j=-1*mean(log(objfn));
    ovecnew=[b e h j];
    %}
    %ovecnew=-1*mean(log(objfn));
    
    %% Mean Variance (has the log)
    %ovecnew=mean(rho*objsb(:,1)-((rho^2)/2)*objsb(:,2));
    ovecnew=mean(objfn);
    %% Without the log 
    %(checked against laura's, i think this is wrong)
    %ovecnew=-mean(exp(-rho*objsb(:,1)+((rho^2)/2)*objsb(:,2)));
end

