function [out3,out4,profitind] = devu4(z,Gamma,informed,...
    altinfo,rhobar,numa,fbar,v,u,q,a0,a2,p,r,kcons,numidio,...
    payoffs)
    
    %% need to apply all fixes in calcdemand2 to devu3
    %% admati
    %Gamma*diag([1/altinfo(1) 1/altinfo(2) 1/altinfo(3)])*Gamma'
    %so we need to update sa here
    altinfo=altinfo+kcons;
    sa=Gamma*diag([ones(numidio,1)*(1/altinfo(1));...
        (1/altinfo(2))])*(Gamma');
    %again, not returned so can do this directly
 
    %new method for defining sa above
    %sa=Gamma*diag([1/altinfo(1) 1/altinfo(2) 1/altinfo(3)])*Gamma';
    
    %% fix 2, typo in K
    %k=inv(a2)-r*rhobar*q;
    k=(1/rhobar)*(inv(a2)-r*q);

    %% fix 3 -- use 'correct' a's to fix g0
    %{
    p1g=eye(numa)-inv((u/q)+rhobar*eye(numa));
    p2g=v\fbar+(q/u)*zbar;
    g0=rhobar*p1g*p2g;
    %}
    g0=a2\a0;
    
    %SCALE UP
    %informed=1000000;
    %informed=informed*100000;
    inftraders=informed;
    
    %% old signal method
    %recall: epsilonj=mvnrnd(zeros(3,1),diag(sigetaj),informed);
    %signals=ones(inftraders,1)*((fbar+Gamma*z)')+(Gamma*epsilonj')';
    %i want to try drawing a second signals and see how things look
    
    %% new signal method
    signals=mvnrnd(payoffs,sa,informed);

    %% fix 4, note, don't need to care about uninformed in devu
    g2inf=rhobar*(k+r*inv(sa)); %just had to fix k
    g1=rhobar*inv(sa); %unchanged
    %g2=rhobar*(k+r*inv(sa));% so this didn't actually change

    %truncate 
    numa=numidio+1; 
    
    %% Add in B's for posterior means in admati model
    vainf=inv(inv(v)+q*(u\q)+inv(sa));
    %{
    b1inf=(1/rhobar)*vainf*g1;
    b0inf=(1/rhobar)*vainf*g0;
    b2inf=r*eye(numa)-(1/rhobar)*vainf*g2;
    %}
    %% i dont think this fix does anything
    b1inf=(1/rhobar)*vainf*g1;
    b0inf=(1/rhobar)*vainf*g0;
    b2inf=r*eye(numa)-(1/rhobar)*vainf*g2inf';
    
    %% big change: switching to this to avoid numerical issues
    %now want to match posterior means of informed
    sighatininv=inv(vainf);    
    ejftildeiadmat=b0inf*ones(1,informed) + ...
        b1inf*signals'+b2inf*p*ones(1,informed);  
    %{
    postmeansadmat=t3-ones(informed,1)*p'*r;
    postpresadmat=sighatininv;
    %}
    t3=ejftildeiadmat';
    
    postmeans=t3-ones(informed,1)*p'*r;
    out3=postmeans;
    out4=sighatininv;    
    
    payoff=fbar+Gamma*z;
    dpt1=ones(inftraders,1)*g0';
    dpt2=(g1*signals')';
    
    %changed to reflect new g2
    %dpt3=ones(inftraders,1)*(g2*p)';
    dpt3=ones(inftraders,1)*(g2inf*p)';
    
    %check that signals integrate to F
    demands=dpt1+dpt2-dpt3;
    %{
    g2inf=rhobar*(k+r*inv(sat));
    g2un=rhobar*k;    
    duninf=g0-g2un*p;
    %}
    profitind=demands*(payoff-p*r); %d is for detail
    %{
    rho=1/rhobar;
    uinformed=-exp(-rho*profitind);
    %{
    mean(profitind)
    size(profitind)  
    %}
    euinformed=mean(uinformed);
    %}
    %{
    disp('dev')
    payoff
    mean(profitind)
    %}
end

