    %% Set Parameters
tic;clc;clear;rng(1)

musys=15;muidio=15; %Set mean payoffs
sigidio=0.55; %set vol of idiosyncratic risk
sigx=0.5;%variance of noise
r=1;%risk free, turn off for now
Wzero=0;%initial wealth
K=1;

kcons=0.001;%v1
%kcons=0.0001;%v2

%for testing mc need a lot more investors to overcome simulation noise
numinv=100000;
%numinv=10000;
toler=0.02; %tolerance for solution finding
tol=0.001; %tolerance for numerical method on laura sols
pdifftol=0.0005;%tol for numerical method on marco sols

%numsim=10000;
numsim=5000;
%numsim=1000;
%numsim=2; %for checking data writing

devsim=numsim;%number of deviation simulations

%going to argue that there is just a hard cap at 8 assets

minassets=2;maxassets=8;%max possible idio assets

%tsupplyidio=8; %fix total supply of idiosyncratic assets
%there is something weird about varying the total supply of idio assets
%it interacts somehow with risk aversion, so they should be intertwined
tsupplyidio=20;

numinfs=16; %# of possible information choices on the grid, for now
%this will go from 0.05 to 0.50 -- model cannot accomodate 0 informed

%need to say how many obs we are saving, but this will be a grid now
numrhos=15;numsigns=15;
%paramsets=numrhos*numsigns; %how many different parameters will we try
paramsets=8;
%% main code (i.e. params already set)
numsave=paramsets*numinfs;
savemat=zeros(numsave,24);
numsave
%alpha=0.001
Mtemp=csvread('nasset_justsols_altmethod_la_supply.csv');
size(Mtemp)
newcter=0;
%#loop over parameters
for rholoop=3:3
%for rholoop= 1:3
    for signloop=1:2
        if rholoop==1
            rho=0.1;
        elseif rholoop==2
            rho=0.25;
        elseif rholoop==3
            rho=0.35;
        elseif rholoop==4
            rho=0.45;
        end
      
        if signloop==1
            sign=0.2;
        elseif signloop==2
            sign=0.5;
        end
        for infloop=1:numinfs
            infshare=0.05*infloop;
            %loop over # of assets (this version it is fixed)
            for numidiol=1:1
                %numidio=numidiol*2;
                numidio=8;
%% Main Code for Solving                
%make the # k steps depend on # assets
%so increment in K is same...
numksteps=50*numidio;%in 2 case it is 100 x 100
stepsize=K/numksteps;
xbaridio=tsupplyidio/numidio;
xbarsys=xbaridio*numidio; 
informed=round(infshare*numinv);

%% Want Gamma to become an input computed outside the price
% function, rather than created inside, can apply to 
% many other model/param specific pieces 
%% beta=0
%{
Gamma=eye(numidio+1);
%}
%% beta=1

p1=eye(numidio+1);
p2=[zeros(numidio+1,numidio) ones(numidio+1,1)];
Gamma=p1+p2;Gamma(numidio+1,numidio+1)=1;
%}
%% Could add more basic calculations like U, V here

%for rho=3
newcter=64;
altinfo=Mtemp(newcter+1,3:4);
trueinfo=Mtemp(newcter+1,3:4);
[sign rho infshare numidio]


[postpres,postpresun,gout,ncmat,ovecnew,...
    pvecin,pvecout,addout] = ...
    masterrunsim_supply_new(numsim,sigidio,sign,sigx,infshare,...
            altinfo,rho,musys,muidio,xbaridio,xbarsys,...
            r,informed,Wzero,numksteps,K,kcons,numinv,...
            numidio,Gamma);
%{        
postpres
postpresun
%gout=[g0 g1 g2inf g2un];
gout
%eus in/out ces in/out, cediff, cediff%, objfndiff cost
ncmat
%profits in/out, utilities in/out, objfns in/out
ovecnew
%profits by asset 
pvecin
pvecout
%}
newcter=newcter+1;
%% baseline
savemat(newcter,1:8)=[trueinfo,altinfo,rho,sign,infshare,numidio];
%% addon 
savemat(newcter,9:24)=[ncmat,ovecnew,addout];
toc

%% additional outputs

s1=num2str(sign);
s2=num2str(rho);
s3=num2str(infshare);
s4=num2str(numidio);
%{
%% output precisions
presmat=[postpres postpresun];
outname2=strcat('prec',s1,s2,s3,s4,'.csv');
csvwrite(outname2,presmat)   

%% output parts of demand function
outname3=strcat('gout',s1,s2,s3,s4,'.csv');
csvwrite(outname3,gout)  

%% output profits by asset 
profitsbyaout=[pvecin pvecout];
outname4=strcat('pibya',s1,s2,s3,s4,'.csv');
csvwrite(outname3,profitsbyaout) 
%}
%% output profits by asset and demand function 
%gout=[g0 g1 g2inf g2un];
combine=[pvecin' pvecout' gout postpres postpresun];
outname5=strcat('combinelasupply',s1,s2,s3,s4,'.csv');
csvwrite(outname5,combine) 
%}
%% additional simulations
%add more sim
s1=num2str(sign);
s2=num2str(rho);
s3=num2str(infshare);
s4=num2str(numidio);
numsimb=10000;
outmatt = ...
        masterrunsim_voldrift2(numsimb,sigidio,sign,sigx,infshare,...
        altinfo,rho,musys,muidio,xbaridio,xbarsys,...
        r,informed,Wzero,numksteps,K,numsimb,kcons,numinv,altinfo,...
        numidio); %alt info is in both places                
%need to not have the +1 b/c we don't have the ETF
%nument=(numidio+1)*numsim;
nument=(numidio+1)*numsimb;
trow=ones(nument,1)*[rho,sign,infshare,numidio];
outmatt2=[trow outmatt];
outname=strcat('voldrift_lasupply',s1,s2,s3,s4,'.csv');
csvwrite(outname,outmatt2)  
%}
            end %end of # assets loop
        end %end of share informed loop
    end %end of sign loop
end %end of rholoop
csvwrite('nasset_simresults_alteu_lasupply.csv',savemat)
