function [turn,vol] =...
    calcdemand_voldrift2(informed,z,Gamma,zz,...
    rhobar,numa,fbar,v,zbar,u,sa,q,a0,a1,a2,p,r,...
    payoffs,supply,numidio,xbar,x,infshare,p0)    

    %% admati demand
    % note: admati model cannot handle all uninformed agents
    %first solve for demand of uninformed
    %% fix 2
    %k=inv(a2)-r*rhobar*q;
    k=(1/rhobar)*(inv(a2)-r*q);
    
    %% fix 3
    %{
    %for gzero
    p1g=eye(numa)-inv((u/q)+rhobar*eye(numa));
    p2g=v\fbar+(q/u)*zbar;
    g0=rhobar*p1g*p2g;
    %}
    g0=a2\a0;
    
    %% adaptation 1
    sat=sa;
    
    %% fix 4, I am moving these calcs up (commented out below)
    g2inf=rhobar*(k+r*inv(sat));
    g2un=rhobar*k;
    
    %% fix 5
    %duninf=rhobar*(g0-k*p);
    duninf=g0-g2un*p;
    duninfp0=g0-g2un*p0;
    
    
    inftraders=informed;
    
    %signals need to be centered on fbar+Gamma*z -- true payoff
    %plus the noise (Gamma*epsilonj')'
    %% old signal method
    %signals=ones(inftraders,1)*((fbar+Gamma*z)')+(Gamma*epsilonj')';
    %i want to try drawing a second signals and see how things look
    
    %% new signal method
    rng(zz)
    signals=mvnrnd(payoffs,sat,informed);
    g1=rhobar*inv(sat);
    
    % changed above
    %g2=rhobar*(k+r*inv(sa));
    
    %these calculations are also unchanged
    dpt1=ones(inftraders,1)*g0';
    dpt2=(g1*signals')';
    
    %changed to reflect new g2
    %dpt3=ones(inftraders,1)*(g2*p)';
    dpt3=ones(inftraders,1)*(g2inf*p)';
    
    dpt3p0=ones(inftraders,1)*(g2inf*p0)';
    
    %check that signals integrate to F
    demands=dpt1+dpt2-dpt3;
    
    demandsp0=dpt1-dpt3p0;
    %check mc at p0
    %{
    avgdemand=infshare*mean(demandsp0)+(1-infshare)*duninfp0';
    totalsupply=zbar;
    [avgdemand' totalsupply]
    
    avgdemand=infshare*mean(demands)+(1-infshare)*duninf';
    totalsupply=zbar+(Gamma')\x;
    [avgdemand' totalsupply]
    %}
    sa=sat;
    numa=numidio+1;
    
    %% Add in B's for posterior means in admati model
    vainf=inv(inv(v)+q*(u\q)+inv(sa));
    vaun=inv(inv(v)+q*(u\q));
    
    %% fix 7
    %{
    b0un=(1/rhobar)*vaun*g0;
    g2un=k;
    b2un=r*eye(numa)-(1/rhobar)*vaun*g2un;
    demandun=rhobar*(vaun\(b0un+(b2un-r*eye(numa))*p));
    b1inf=(1/rhobar)*vainf*g1;
    b0inf=(1/rhobar)*vainf*g0;
    b2inf=r*eye(numa)-(1/rhobar)*vainf*g2;
    %}
    % for uninformed, will need later when computing cost
    b0un=(1/rhobar)*vaun*g0;
    b2un=r*eye(numa)-(1/rhobar)*vaun*g2un;
    
    b1inf=(1/rhobar)*vainf*g1;
    b0inf=(1/rhobar)*vainf*g0;
    b2inf=r*eye(numa)-(1/rhobar)*vainf*g2inf';
    
    %price=((a0+a1*(fbar+Gamma*z)-a2*(zbar+(Gamma')\x)))
    %so unbiased signal about z (not f!) is 
    %sigpnew=(a1*Gamma)\(p-a0-a1*fbar+a2*zbar);
    %% big change: switching to this to avoid numerical issues
    %sighatuninv=inv(v)+q*(u\q);
    
    %now want to match posterior means of informed
    sighatininv=inv(vainf);   
    sighatuninv=inv(vaun);
    ejftildeiadmat=b0inf*ones(1,informed) + ...
        b1inf*signals'+b2inf*p*ones(1,informed);
    t3=ejftildeiadmat';
    postmeanun=b0un+b2un*p;

    %Add turnover
    meansupply=(Gamma')\xbar;
    supply=zbar+(Gamma')\x;
    supplyshock=(Gamma')\x;
    
    %need to drop last entry to match dimensions

    
    mc=infshare*mean(demands)'+(1-infshare)*duninf;
    [supply mc]
    %[duninf mean(demands)']
    %}
    %% average method, ignore shock
    
    [duninf mean(demands)' supply  z x]
    %}
    %{
    size(duninf)
    size(mean(demands))
    size(meansupply)
    %}
    trade_un=duninf-meansupply;
    vol_un=abs(trade_un);
    trade_in_avg=mean(demands)'-meansupply;
    vol_in=abs(trade_in_avg);
    vol1=infshare*vol_in+(1-infshare)*vol_un;
    turn1=vol1./meansupply;
    
    %% average method, include shock
    trade_un=duninf-supply;
    vol_un=abs(trade_un);
    trade_in_avg=mean(demands)'-supply;
    vol_in=abs(trade_in_avg);
    vol2=infshare*vol_in+(1-infshare)*vol_un;
    turn2=vol2./supply;
    
    %% individual trader method (without shock)
    %demands is 500x9, supply is 9x1
    trade_un=duninf-meansupply;
    vol_un=abs(trade_un);
    %500x9 trade informed
    trade_in=demands-ones(informed,1)*meansupply';
    %take abs for each
    trade_ina=abs(trade_in);
    vol_in=mean(trade_ina)';
    vol3=infshare*vol_in+(1-infshare)*vol_un;
    turn3=vol3./meansupply;
    
    %% individual trader method (with shock)
    %demands is 500x9, supply is 9x1
    trade_un=duninf-supply;
    vol_un=abs(trade_un);
    %500x9 trade informed
    trade_in=demands-ones(informed,1)*supply';
    %take abs for each
    trade_ina=abs(trade_in);
    vol_in=mean(trade_ina)';
    vol4=infshare*vol_in+(1-infshare)*vol_un;
    turn4=vol4./supply;
    
    turn=[turn1 turn2 turn3 turn4];
    vol=[vol1 vol2 vol3 vol4];
end

