%going back to non symmetric case for generality
function solmat = find_solutionssym(sign,rho,sigidio,xbaridio,...
    xbarsys,sigx,K,infshare,toler,numksteps,kcons,numidio)
    
    solmat=[];solutions=[];solcount=0;%allocate memory
    stepsize=K/numksteps;
    %for infsys=0.5:0.01:0.5
    for infsys=0:stepsize:K
        solution=0;
        infidio=(K-infsys)/numidio;
        %% function 1: calculate lambdas, 1+ is inside this fn.
        [~,~,lams] = calclamssym(sign,rho,sigidio,...
            xbaridio,xbarsys,sigx,infshare,kcons,infidio,infsys);
        %only need to check two conditions now, b/c of assumed symmetry
        d1=abs(lams(1)-lams(2));
        %lams at 2 is the sytematic
        
        %all attention on systematic assets
        if lams(2)-lams(1)>toler && infsys==K
            solution=1;soltype=1;
        %all on idio assets    
        elseif lams(1)-lams(2)>toler && infsys==0
            solution=1;soltype=2;
        else
            if d1<toler
               solution=1;soltype=3;
            else
                solution=0;
            end
        end
        
        if solution==1
            solcount=solcount+1;          
            %keep track of soltype
            solutions(solcount,:)=...
                [lams,infidio,infsys,soltype,sign,rho,d1];
        end
    end
    [snum,~]=size(solutions);
    if snum>0 %there is a solution
        sortsol=sortrows(solutions,8);
        solmat=[solmat;sortsol(1,:)];
    else %there is no solution
       solmat=-1*ones(1,8);
    end

end

