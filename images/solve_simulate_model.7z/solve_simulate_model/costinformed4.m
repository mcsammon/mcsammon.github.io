%same file as testfnsym with different output
function [infocostvec,profits3,postpres,...
    postpresun,gout,ncmat] ...
    = costinformed4(infshare,info,rho,sigx,sign,sigidio,...
    xbaridio,xbarsys,kcons,numsim,musys,muidio,r,informed,Wzero,numksteps,...
    K,devsim,numinv,devinfos,numidio)
        %{
        info 
        devinfos
        %}
        %% program 3, master run sim
        [pms,postpres,postpresdeva,pmsdeva,pmsun,postpresun,...
            profits3,gout,ncmat] = ...
            masterrunsim4(numsim,sigidio,sign,sigx,infshare,...
            info,rho,musys,muidio,xbaridio,xbarsys,...
            r,informed,Wzero,numksteps,K,devsim,kcons,numinv,devinfos,...
            numidio);
            
        %% program 4, calculate deviation utility
        [actual,alt]=finaleu4(pms,postpres,r,Wzero,info,...
            postpresdeva,pmsdeva,devinfos);
        %4th post is veldkamp, 5th pos is admati
        alteu=alt(3);
        %add in uninformed
        v=cov(pmsun);%calculate vcv of posterior means
        t1=postpresun*v;t2=0.5*trace(t1);
        mp=mean(pmsun);
        t3=0.5*mp*postpresun*mp';
        euiun=r*Wzero+t2+t3;%ex-ante expected utility 
        infocost=actual(3)-euiun;
        euin=actual(3);
        infocostvec=[infocost,euin,euiun];
end

