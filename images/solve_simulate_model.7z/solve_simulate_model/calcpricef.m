%% info=[infidio infsys];
function [rhobar,numa,fbar,v,zbar,u,sa,q,a0,a1,a2,p,...
    payoffs,supply] = ...
        calcpricef(infshare,info,sigx,rho,...
        sigidio,sign,musys,muidio,...
        xbaridio,xbarsys,x,z,r,kcons,numidio,Gamma)
    %add baseline learning
    info=info+kcons; 
    %setup Gamma
    %{
    p1=eye(numidio+1);
    p2=[zeros(numidio+1,numidio) ones(numidio+1,1)];
    Gamma=p1+p2;Gamma(numidio+1,numidio+1)=1;
    %}
    %set up mean payoffs, and unrotated mean noise shocks
    mu=[ones(numidio,1)*muidio;musys];
    xbar=[ones(numidio,1)*xbaridio;xbarsys];
    
    %% admati prices
    rhobar=1/rho;%avg. risk aversion -> risk tolerance
    numa=numidio+1;%number of assets
    fbar=mu;%mean of asset payoffs
    %asset payoff variance
    v=Gamma*diag([ones(numidio,1)*sigidio;sign])*(Gamma');
    %asset supply variance
    zbar=(Gamma')\xbar;
    %From veldkamp asset supplies = (gamma')^{-1} * (xbar + x)
    u=((Gamma')\(sigx*eye(numa)))*inv(Gamma')';
    %if noise shocks were independent
    %u=sigx*eye(numa);
    
    %Something like precision 
    sa=Gamma*diag([ones(numidio,1)*(1/info(1));...
        (1/info(2))])*(Gamma');
    
    supply=zbar+(Gamma')\x;
    payoffs=fbar+Gamma*z;
    
    %% for n-1 asset version will have to actually modify these.
    %Want to return full matricies, so just put in t's
    vt=v;ut=u;sat=sa;zbart=zbar;fbart=fbar;
    
    q=rhobar*infshare*inv(sat);qt=q;
    
    pt1=rhobar*inv(vt)+rhobar*q*(ut\q)+q;
    pt2=(vt\fbart)+q*(ut\zbart);
    pt3=(q+rhobar*q*(ut\q));
    pt4=eye(numidio+1)+rhobar*(q/ut);
    a0=(rhobar/r)*(pt1\pt2);
    a1=(1/r)*(pt1\pt3);
    a2=(1/r)*(pt1\pt4);
    p=a0+a1*payoffs-a2*supply;
    
    %% Check 1: Price with zero shocks (Works)
    %{
    %from above
    p0fn=a0+a1*fbar-a2*zbar;
    %from eq 31 in admati
    p0=(1/r)*(fbart-inv(rhobar*inv(vt)+...
        rhobar*qt*inv(ut)*qt+qt)*zbart);
    [p0fn p0]
    %}
end

