function diff=testfnrot(Gamma,numidio,kcons,...
                        vhalf,rotinfo,Lstar)
    info1=rotinfo(1);
    info2=rotinfo(2);
    %% Check 1: When everything is diagonal, this is the correct sigma-e
    %infact, it is equal to L*
    sigmae=Gamma*diag([ones(numidio,1)*(1/(kcons+info1));...
        (1/(kcons+info2))])*(Gamma');
    %defn=inv(vhalf)*sigmae*inv(vhalf)
    defn=vhalf\sigmae/(vhalf');
    defn=(defn+defn')/2;%have to do this for matlab's sake
    [G,L]=eig(defn); 
    %% check 2; do we satisfy properties of eigen decomposition
    %{
    norm(G*L*G'-defn)
    norm(G'*G-eye(numidio+1))
    %}
    
    a=vhalf*G*Lstar*G'*vhalf;
    b=sigmae;
    diff=norm(abs(a-b));
end

