function [z,x] = drawshocks2(sigidio,sign,sigx,numidio)
    sig=[sigidio*ones(numidio,1);sign];
    z=mvnrnd(zeros(numidio+1,1),diag(sig))'; %shocks to factors
    x=mvnrnd(zeros(numidio+1,1),sigx*eye(numidio+1))'; %shocks to asset supplies

end

