%info=[infidio infsys];
function [pms,postpres,postpresdeva,pmsdeva,pmsun,postpresun,...
    profits3,gout,ncmat,ovecnew] = ...
    masterrunsimf(numsim,sigidio,sign,sigx,infshare,...
            info,rho,musys,muidio,xbaridio,xbarsys,...
            r,informed,Wzero,numksteps,K,devsim,kcons,numinv,devinfos,...
            numidio,Gamma)
    
    altinfo=devinfos;
    pms=zeros(numsim*informed,numidio+1);
    pmsun=zeros(numsim,numidio+1);
    pmsdeva=zeros(numsim*informed,numidio+1);
    postpresdeva=zeros(numidio,numidio+1);
    profits=zeros(numsim,(numidio+1)*3);
    %new utility calc
    utilities=zeros(numsim,2); 
    utilitiesinf=zeros(numsim*informed,1);
    utilitiesinfdev=zeros(numsim*informed,1);
    profitsinf=zeros(numsim*informed,1);    
    profitsinfdev=zeros(numsim*informed,1);    
    profitsun=zeros(numsim,1);
    utilitiesun=zeros(numsim,1);
    objfn=zeros(numsim,3);
    for zz=1:numsim  
 
        rng(zz)%Fix RNG across sims, can test turning off shocks below
        [z,x] = drawshocks2(sigidio,sign,sigx,numidio);

        %zz %display simnum
           
        [postmeans,postpres,out3,out4,postmeanun,sighatuninv,...
            profitin,profitun,avgprofit,gout,profitind,...
            profitinddev] = ...
            runsimfastf(sigidio,sign,sigx,infshare,...
            info,rho,musys,muidio,xbaridio,xbarsys,...
            r,informed,Wzero,numksteps,K,devsim,kcons,z,x,zz,altinfo,...
            numidio,Gamma);
        %mean(profitind) %% profits by trader
        %mean(profitinddev) %% dev profits by traded       
        %total trading profits by group
        tprofitin=sum(profitin);
        tprofitun=sum(profitun); %% Profits by uninformed trader
        %utility by group, which we want to save
        uin=-exp(-rho*tprofitin);uun=-exp(-rho*tprofitun);
        utilities(zz,:)=[uin,uun];
        
        %out 1 is the posterior means, out2 is the precision, out3 is the info
        if zz==1
            postpresdeva=out4;
        end
        index1=1+(zz-1)*informed;
        index2=zz*informed;
        pms(index1:index2,:)=postmeans;
        pmsdeva(index1:index2,:)=out3;
        
        %new save profits/utilities
        profitsinf(index1:index2,:)=profitind;
        profitsinfdev(index1:index2,:)=profitinddev;
        profitsun(zz)=tprofitun;
        
        utilitiesinf(index1:index2,:)=-exp(-rho*profitind);        
        utilitiesinfdev(index1:index2,:)=-exp(-rho*profitinddev); 
        utilitiesun(zz)=-exp(-rho*tprofitun);
        
        pmsun(zz,:)=postmeanun;
        profits(zz,:)=[profitin',profitun',avgprofit'];
        
        a=mean(exp(-rho*(profitind)));
        b=mean(exp(-rho*(profitinddev)));
        c=mean(exp(-rho*(profitun)));
        objfn(zz,:)=[a,b,c];
    end %end of simulation loop
    
    a=mean(profitsinf);
    b=mean(profitsinfdev);
    c=mean(profitsun);
    d=mean(utilitiesinf);
    e=mean(utilitiesinfdev);
    f=mean(utilitiesun)';
    %mean variance prefs
    g=rho*mean(profitind)-((rho^2)/2)*var(profitind);
    h=rho*mean(profitinddev)-((rho^2)/2)*var(profitinddev);
    i=rho*mean(profitsun)-((rho^2)/2)*var(profitsun);
    j=-1*mean(log(objfn));
    ovecnew=[a b c d e f g h i j];
    %ovecnew
    %}
    postpresun=sighatuninv;
    profits2=mean(profits)';
    stp=numidio+1;
    profits3=[profits2(1:stp),profits2(stp+1:2*stp),profits2(2*stp+1:3*stp)];    
%expected utilities, 1st and 3rd elements are 'right'
    %2nd element is if we take avg profit vs. individual profits
    eus=[mean(utilitiesinf) mean(utilities)];
    %calculate the CEs for the expected utilities
    ces=(-1/rho)*log(-1*eus);
    %calculate $c$ in dollars
    cediff=(ces(1)-ces(3));
    
    %check -- if c is correct, EU of informed and uninformed
    %should be equal
    %{
    newwealth=profitsinf-cediff;
    neweu=mean(-exp(-rho*newwealth))
    %}
    %cost as fn of CE
    c=cediff/ces(1);
    %Need a way to save everything
    %call it new cost mat
    %[eu(inf) eu(un) ce(inf) ce(un) cost(dollars) cost(share ce)]
    ncmat=[eus(1) eus(3) ces(1) ces(3) cediff c];
    
end

