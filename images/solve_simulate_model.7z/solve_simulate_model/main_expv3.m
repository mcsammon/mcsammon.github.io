%% Set Parameters
tic;clc;clear;rng(1)

musys=15;muidio=15; %Set mean payoffs
sigidio=0.55; %set vol of idiosyncratic risk
sigx=0.5;%variance of noise
r=1;%risk free, turn off for now
Wzero=0;%initial wealth
K=1;kcons=0.05;%setting k cons to zero brings us back to veldkamp's model

%for testing mc need a lot more investors to overcome simulation noise
numinv=100000;
%numinv=10000;
toler=0.02; %tolerance for solution finding
tol=0.001; %tolerance for numerical method

%numsim=10000;
numsim=5000;
%numsim=1000;
%numsim=2; %for checking data writing

devsim=numsim;%number of deviation simulations

%going to argue that there is just a hard cap at 8 assets
minassets=8;maxassets=8;%max possible idio assets
%tsupplyidio=8; %fix total supply of idiosyncratic assets
%there is something weird about varying the total supply of idio assets
%it interacts somehow with risk aversion, so they should be intertwined
tsupplyidio=20;

numinfs=16; %# of possible information choices on the grid, for now
%this will go from 0.05 to 0.50 -- model cannot accomodate 0 informed

%need to say how many obs we are saving, but this will be a grid now
numrhos=15;numsigns=15;
paramsets=numrhos*numsigns; %how many different parameters will we try

%% main code (i.e. params already set)
numsave=paramsets*numinfs*(minassets-maxassets+1);
savemat=zeros(numsave,21);

newcter=0;
%#loop over parameters
for rholoop= 1:2
    for signloop=1:2
        if rholoop==1
            rho=0.1;
        elseif rholoop==2
            rho=0.25;
        end
        
        if signloop==1
            sign=0.2;
        elseif signloop==2
            sign=0.5;
        end
        
        
        %going to get rid of the infloop 
        %b/c just going to to targeted info loop stuff
        for infloop=1:numinfs
            infshare=0.05*infloop;
            
            sign=0.2; rho=0.1;infshare=0.2;
            sign
            rho
            infshare
            %loop over # of assets (this version it is fixed)
            for numidio=minassets:maxassets
%% Main Code for Solving                
%make the # k steps depend on # assets
%so increment in K is same...
numksteps=50*numidio;%in 2 case it is 100 x 100
stepsize=K/numksteps;
xbaridio=tsupplyidio/numidio;
xbarsys=xbaridio*numidio; 
informed=round(infshare*numinv);
%this is what laura's model would predict
%IF the ETF was present

solmat=find_solutionssym(sign,rho,sigidio,xbaridio,...
    xbarsys,sigx,K,infshare,toler,numksteps,kcons,numidio);
infsys=solmat(4);infidio=solmat(3);
trueinfo=[infidio infsys];
%}

%% Check 1: Match laura's solutions, Known Working
%{
for i = 1:6
    if i==1
        sign=0.5;
        rho=0.175;
    elseif i==2
        sign=0.25;
        rho=0.175;
    elseif i==3
        sign=0.25;
        rho=0.35;
    elseif i==4
        sign=0.25;
        rho=0.175;
    elseif i==5
        sign=0.5;
        rho=0.35;
    elseif i==6
        sign=0.25;
        rho=0.175;
    end
    rng(1)
    xbaridio=1;xbarsys=15;infshare=0.2;numidio=2;kcons=0;
    %numksteps=800;toler=0.01;
    solmat=find_solutionssym(sign,rho,sigidio,xbaridio,...
        xbarsys,sigx,K,infshare,toler,numksteps,kcons,numidio);
    infsys=solmat(4);infidio=solmat(3);
    trueinfo=[infidio infsys]
end
%}
%% Want Gamma to become an input computed outside the price
% function, rather than created inside, can apply to 
% many other model/param specific pieces 

%% beta=0

Gamma=eye(numidio+1);
%}

%% beta=1
%{
p1=eye(numidio+1);
p2=[zeros(numidio+1,numidio) ones(numidio+1,1)];
Gamma=p1+p2;Gamma(numidio+1,numidio+1)=1;
%}
%% Could add more basic calculations like U, V here

%% Check 2: Rotation, this works for Gamma=Eye
%Laura's params
%sign=0.25;rho=0.175;
rho=0.3;sign=0.175;
xbaridio=1;xbarsys=15;infshare=0.2;numidio=2;

kcons=0.05;%need this or rotation might hit corner

%% beta=0

Gamma=eye(numidio+1);
%}
%% beta=1
%{
p1=eye(numidio+1);
p2=[zeros(numidio+1,numidio) ones(numidio+1,1)];
Gamma=p1+p2;Gamma(numidio+1,numidio+1)=1;
%}

v=Gamma*diag([ones(numidio,1)*sigidio;sign])*(Gamma');
vhalf=sqrtm(v); %adj for diagonal gamma

%In the paper, they solve the model with var(f tilde)=
%some diagonal matrix.  But in the appendix, they require
%that var(f)=I, which would also require rotating the
%asset supplies and asset supply variances
%% Solve the orthogonal version of the model 
solmat=find_solutionssym(sign,rho,sigidio,xbaridio,...
    xbarsys,sigx,K,infshare,toler,numksteps,kcons,numidio);
infsys=solmat(4);infidio=solmat(3);
trueinfo=[infidio infsys];

%% Solve the rotation (for now, comment out b/c
%% we are doing the orthogonal model
%{
mindist=100;%set initial distance to something huge
minK=-1; %set negative so we know if no solution was found
numisteps=10;%how granular multiple starting points are
stop=numisteps-1;
options = optimoptions('fmincon','Display','off');
%for Ktemp=1:1, test for just k=1
for Ktemp=0.1:0.05:3 %loop over total info
    Ktemp
    %find solutions with Ktemp as the limit
    solmat=find_solutionssym(sign,rho,sigidio,xbaridio,...
        xbarsys,sigx,Ktemp,infshare,toler,numksteps,kcons,numidio);          
    infsys=solmat(4);infidio=solmat(3);
    tempinfo=[infidio infsys];
    %Construct L* using laura's solutions
    Lstar=diag([ones(numidio,1)*(1/(kcons+tempinfo(1)));...
            (1/(tempinfo(2)+kcons))]);
    %Here is the rotation:
    %vhalf*G*L*G'*vhalf=sigmaE
    %I am going to eleminate the vhalf part b/c
    %I am solving the rotated model with unequal variances
    %v4 has the vhalf part, v3 does not
    frotate=@(rotinfo) testfnrot3(Gamma,numidio,kcons,...
        rotinfo,Lstar);
    %{
    frotate(tempinfo)
    frotate(trueinfo)
    %}
    mindiff=10000;mininfo=[-99,-99];%reset
    for i =1:stop
        %choose start
        x0=[(i/numisteps)/numidio,1-(i/numisteps)];
        %frotate(x0)
        %solve rotation with no forgetting

        [mininfof,v1]=fmincon(frotate,x0,[],[],[],[],[0,0],...
            [],[],options);
        %save if better
        if v1<mindiff
            mindiff=v1;mininfo=mininfof;
        end
    end
    %how much info did this need?
    tsum=mininfo(1)*numidio+mininfo(2);dist=abs(tsum-1);
    %how close are we to 1?
    if dist<mindist
        mindist=dist;minK=Ktemp;finfo=mininfo;
    end
end
[minK finfo(1)*numidio+finfo(2) mindist]
finfo                
%}
trueinfo

%let's start out at some suboptimal info
%altinfo=[(K/2)/numidio,K/2];
%or try starting at optimal info
altinfo=trueinfo;
%altinfo=[0,1];

zkz=1;breakcode=0;
%keep track of oscilation
movehist=zeros(100,1);


%% Commenting out for now to speed up

%working, so this is back on
while breakcode==0
    %zkz
    
    %again, needs to be defined with respect to alt info
    %% faster fn
    fn2=@(devinfos) testfnsymf2(infshare,altinfo,rho,sigx,sign,sigidio,...
    xbaridio,xbarsys,kcons,numsim,musys,muidio,r,informed,Wzero,numksteps,...
    K,devsim,numinv,devinfos,numidio,Gamma);
    %fn2(altinfo)
    %% old fn
    %{
    fn3=@(devinfos) testfnsymf(infshare,altinfo,rho,sigx,sign,sigidio,...
    xbaridio,xbarsys,kcons,numsim,musys,muidio,r,informed,Wzero,numksteps,...
    K,devsim,numinv,devinfos,numidio,Gamma);
    %}
    %so fn2 computes  your expected utility, conditional on everyone being
    %at 'altinfo'
    %now, rather than compute entire grid, just compute
    %two directions: inc learn 1 and learn 2, 
    %dec learn 1 and learn 2
    
    %need to move on grid, right now altinfo has order 
    %info=[infidio infsys];
    
    %hugely faster
    %{
    tic
    base1=fn2(altinfo)
    toc
    tic
    base2=fn3(altinfo)
    toc
    base1-base2
    %}
    base=fn2(altinfo);
    aup=altinfo+[stepsize,-numidio*stepsize];
    adown=altinfo-[stepsize,-numidio*stepsize];
    %}
    %{
    aup=[0,1];
    adown=[1/numidio,0];
    %}
    up=fn2(aup);%more on 1 and 2
    down=fn2(adown);
    altinfoold=altinfo;
    %[base up down]
    %something weird about eq in 3
    %{
    %testing wider range
    aup2=altinfo+[2*stepsize,-2*numidio*stepsize];
    adown2=altinfo-[2*stepsize,-2*numidio*stepsize];
    up2=fn2(aup2);
    down2=fn2(adown2);        

    aup3=altinfo+[3*stepsize,-3*numidio*stepsize];
    adown3=altinfo-[3*stepsize,-3*numidio*stepsize];
    up3=fn2(aup3);
    down3=fn2(adown3);  

    [down3 down2 down base up up2 up3]
    %}
    if up>base && down>base
        disp('error')
        move=4;
    elseif up>base && down<base
        altinfo=aup;
        move=1;
    elseif down>base && up<base
        altinfo=adown;
        move=2;
    else%exactly equal, or base greater
        breakcode=1;
        move=3;
    end
    [base up down move]
    %[100*log(base) 100*log(up) 100*log(down) move]
    
    movehist(zkz)=move;

    % save actual utility
    actualeu=fn2(altinfoold);
    %compare to best deviation
    deveu=fn2(altinfo);
    %% how much we are improving?
    %eventually could add stop based on this
    inceu=deveu-actualeu;


    %% need to write a stopping when would go to edge of grid...
    edge1=altinfo(1)+stepsize;
    %3 moves in steps of 2
    edge3=altinfo(2)+numidio*stepsize;
    %need to think about 5050 edge as well
    if abs(edge3-K)<tol && move==2
        disp('edge3')
        altinfo=[0;K]';
        breakcode=1;
    elseif abs(edge1-K/numidio)<tol && move==1
        disp('edge 1 and 2')
        altinfo=[K/numidio;0]';
        breakcode=1;
    end

    if(min(altinfo))<0
        disp('goneg')
        if altinfo(2)>altinfo(1) 
            altinfo=[zeros(numidio,1);K]';
        else
            altinfo=[ones(numidio,1)*K/numidio;0]';
        end
        breakcode=1;
    end
    if zkz>=5
       if movehist(zkz)==movehist(zkz-2) && ...
               movehist(zkz)==movehist(zkz-4) && ...
               movehist(zkz)~=movehist(zkz-1)      
           disp('osc')
           breakcode=1;
           %set to last one i.e. before last oscilation?
           altinfo=altinfoold;
       end
    end
    zkz=zkz+1;
    %how slow is slow?
    if zkz==numksteps %size of movehist
        disp('slow')
        breakcode=1;
    end
    %negative gradient would suggest to decrease info1 and info2
    %for symmetric case, just try moving to edge of grid in each direction?
end
%}
%placeholder
%altinfo=[1/8,0];
altinfo
trueinfo
%% For testing
%numsim=500;

%% This is a vestage of the old way of doing things, but I'm leaving
%it here to prevent a change in the output format 
rng(1)%fix rng for calculating cost of becoming informed
infocost1=costinformed2(infshare,trueinfo,rho,sigx,sign,sigidio,...
xbaridio,xbarsys,kcons,numsim,musys,muidio,r,informed,Wzero,numksteps,...
K,devsim,numinv,trueinfo,numidio);

rng(1)%fix rng for calculating cost of becoming informed
infocost2=costinformed2(infshare,altinfo,rho,sigx,sign,sigidio,...
xbaridio,xbarsys,kcons,numsim,musys,muidio,r,informed,Wzero,numksteps,...
K,devsim,numinv,altinfo,numidio);

rng(1)
[infocostvec,profits3,postpres,...
    postpresun,gout,ncmat] ...
    = costinformed4(infshare,altinfo,rho,sigx,sign,sigidio,...
    xbaridio,xbarsys,kcons,numsim,musys,muidio,r,informed,Wzero,numksteps,...
    K,devsim,numinv,altinfo,numidio);

presmat=[postpres postpresun];
idioprofit=mean(profits3(1:numidio,:));

%% To add here, data on trading profits/precision

newcter=newcter+1;
savemat(newcter,1:21)=[trueinfo,altinfo,rho,sign,infshare,...
    numidio,infocost1,infocost2,...
    infocostvec(2),infocostvec(3),...
    idioprofit,ncmat];

%As with the code with n-assets, going to put
%a new function down here.  one diff is that we should
%be using 'altinfo' i.e. info from my numerical solution
%{
outmatt = ...
        masterrunsim_voldrift(numsim,sigidio,sign,sigx,infshare,...
        altinfo,rho,musys,muidio,xbaridio,xbarsys,...
        r,informed,Wzero,numksteps,K,devsim,kcons,numinv,altinfo,...
        numidio); %alt info is in both places
%}
%add more sim
numsimb=10000;

outmatt = ...
        masterrunsim_voldrift(numsimb,sigidio,sign,sigx,infshare,...
        altinfo,rho,musys,muidio,xbaridio,xbarsys,...
        r,informed,Wzero,numksteps,K,numsimb,kcons,numinv,altinfo,...
        numidio); %alt info is in both places                
%need to not have the +1 b/c we don't have the ETF
%nument=(numidio+1)*numsim;
nument=(numidio)*numsimb;
%infocost2 is from altinfo
trow=ones(nument,1)*[altinfo,rho,sign,infshare,numidio,infocost2];
outmatt2=[trow outmatt];
s1=num2str(sign);
s2=num2str(rho);
s3=num2str(infshare);
outname=strcat('bsnoetfv2',s1,s2,s3,'.csv');
csvwrite(outname,outmatt2)
outname2=strcat('prec',s1,s2,s3,'.csv');
csvwrite(outname2,presmat)        
outname3=strcat('gout',s1,s2,s3,'.csv');
csvwrite(outname3,gout)                      
            end %end of # assets loop
        end %end of share informed loop
    end %end of sign loop
end %end of rholoop

csvwrite('compstat_noetf_fixcost_altsolve.csv',savemat)