%% info=[infidio infsys];
function [postmeans,postpres,out3,out4,postmeanun,sighatuninv,...
    profitin,profitun,avgprofit,gout,profitind,...
    profitinddev] = ...
            runsimfastf(sigidio,sign,sigx,infshare,...
            info,rho,musys,muidio,xbaridio,xbarsys,...
            r,informed,Wzero,numksteps,K,devsim,kcons,z,x,zz,altinfo,...
            numidio,Gamma)

    %% program4 calc price
    %I saved a v4 as a test, 
    %but I don't think we actually need it based on n-asset case
    [rhobar,numa,fbar,v,zbar,u,sa,q,a0,a1,a2,p,...
    payoffs,supply] = ...
        calcpricef(infshare,info,sigx,rho,...
        sigidio,sign,musys,muidio,...
        xbaridio,xbarsys,x,z,r,kcons,numidio,Gamma);

    %% program5 demands
    [t3,sighatininv,postmeanun,sighatuninv,...
        profitin,profitun,gout,profitind] =...
    calcdemandf2(informed,z,Gamma,zz,...
    rhobar,numa,fbar,v,zbar,u,sa,q,a0,a1,a2,p,r,...
    payoffs,supply,numidio,infshare,info);
    
    %% scale up
    %informed=1000000;
    postmeans=t3-ones(informed,1)*p'*r;
    postmeanun=postmeanun-p*r;
    postpres=sighatininv;
    
    %if we increase attention on sys risk, does dev profit
    %on sys risk increase?
    %altinfo=[0,1]
    %% deviation utility  
    [out3,out4,profitinddev,profitindev] = devuf(z,Gamma,informed,...
    altinfo,rhobar,numa,fbar,v,u,q,a0,a2,p,r,kcons,numidio,...
    payoffs,zz);
    %{
    altinfo
    mean(profitinddev)
    profitindev
    info
    mean(profitind)
    profitin
    %}
    %test
    %{
    mean(out3)
    mean(out4)
    %}
    avgprofit=infshare*profitin+(1-infshare)*profitun;
end

