%info=[infidio infsys];
function [postpres,postpresun,gout,ncmat,ovecnew,...
    pvecin,pvecout,addout] = ...
    run8(numsim,sigidio,sign,sigx,infshare,...
            info,rho,musys,muidio,xbaridio,xbarsys,...
            r,informed,Wzero,numksteps,K,kcons,numinv,...
            numidio,Gamma)
    %what do we want?
    %profits by informed/uninformed
    %utility by informed/uninformed
    %then, profits by asset class by informed/uninformed
    
    %% fix mat size
    informed=10000;%otherwise this gets too huge
    %new utility calc
    profitsinf=zeros(numsim*informed,1);    
    profitsun=zeros(numsim,1);
    objfn=zeros(numsim,2);
    profitsbyain=zeros(numsim*informed,numidio+1);
    profitsbyaun=zeros(numsim,numidio+1);
    
    %% new
    objsv=zeros(numsim*informed,2);
    objsunv=zeros(numsim,2);
    %% for test
    %objfnt=zeros(numsim,1);
    for zz=1:numsim  
 
        rng(zz)%Fix RNG across sims, can test turning off shocks below
        [z,x] = drawshocks2(sigidio,sign,sigx,numidio);
        %zz %display simnum
           
        [postpres,postpresun,profitun,profitind,gout,profitindba,...
            objs,objsun] = ...
            runsimfastf3(sigidio,sign,sigx,infshare,...
            info,rho,musys,muidio,xbaridio,xbarsys,...
            r,informed,Wzero,numksteps,K,kcons,z,x,zz,numidio,Gamma);
        %{
        postpres
        postpresun
        profitun'
        mean(profitindba)
        sum(profitun)
        mean(profitind)
        %}
        %out 1 is the posterior means, out2 is the precision, out3 is the info
        index1=1+(zz-1)*informed;
        index2=zz*informed;
        
        %% new
        objsv(index1:index2,:)=objs;
        objsunv(zz,:)=objsun;
        %new save profits/utilities
        tprofitun=sum(profitun); %% Profits by uninformed trader
        profitsinf(index1:index2,:)=profitind;
        profitsun(zz)=tprofitun;
        
        profitsbyain(index1:index2,:)=profitindba;
        profitsbyaun(zz,:)=profitun';
        
        a=mean(exp(-rho*(profitind)));
        b=mean(exp(-rho*(profitun)));
        
        objfn(zz,:)=[a,b];        
        %% check that cost 2 is working
        %objfnt(zz,:)=mean(exp(-rho*(profitind-17.9208)));
    end %end of simulation loop
    
    utilitiesinf=-exp(-rho*profitsinf);        
    utilitiesun=-exp(-rho*profitsun);
               
    a=mean(profitsinf);
    c=mean(profitsun);
    d=mean(utilitiesinf);
    f=mean(utilitiesun);
    %mean variance prefs
    j=-1*mean(log(objfn));
    ovecnew=[a c d f j];
    
    %% works!
    %{
    j
    j2=-1*mean(log(objfnt))
    %}
    %ovecnew
    pvecin=mean(profitsbyain);
    pvecout=mean(profitsbyaun);
    
    %% old ncmat
    %{
    %2nd element is if we take avg profit vs. individual profits
    eus=[mean(utilitiesinf) mean(utilitiesun)];
    %calculate the CEs for the expected utilities
    ces=(-1/rho)*log(-1*eus);
    %calculate $c$ in dollars
    cediff=(ces(1)-ces(2));
    %% check 1 -- if c is correct, EU of informed
    %and uninformed should be equal -- works
    %{
    newwealth=profitsinf-cediff;
    neweu=mean(-exp(-rho*newwealth))
    mean(utilitiesun)
    %}
    costtwo=(j(1)-j(2))/rho;
    
    %cost as fn of CE
    c=cediff/ces(1);
    %Need a way to save everything
    %call it new cost mat
    %[eu(inf) eu(un) ce(inf) ce(un) cost(dollars) cost(share ce)]
    ncmat=[eus(1) eus(2) ces(1) ces(2) cediff c costtwo];
    %}
    
    %{
    mean(rho*objsv(:,1)-((rho^2)/2)*objsv(:,2))
    mean(rho*objsunv(:,1)-((rho^2)/2)*objsunv(:,2))
    %}
    euin2=mean(-exp(-rho*objsv(:,1)+((rho^2)/2)*objsv(:,2)));
    euun2=mean(-exp(-rho*objsunv(:,1)+((rho^2)/2)*objsunv(:,2)));
    cein=log(-euin2)/(-rho);
    ceun=log(-euun2)/(-rho);
    cediff2=cein-ceun;
    cost2=log(euun2/euin2)/rho;
    c2=cediff2/cein;
    %% change to new ncmat
    ncmat=[euin2 euun2 cein ceun cediff2 c2 cost2];
    %{
    ncmat
    ncmat2
    %}
    
    a=mean(rho*objsv(:,1)-((rho^2)/2)*objsv(:,2));
    b=mean(rho*objsunv(:,1)-((rho^2)/2)*objsunv(:,2));
    addout=[a b a-b];
    %{
    euin3=-1*mean(-exp(-rho*objsv(:,1)+((rho^2)/2)*objsv(:,2)));
    euun3=-1*mean(-exp(-rho*objsunv(:,1)+((rho^2)/2)*objsunv(:,2)));   
    %}
    %addout
end

