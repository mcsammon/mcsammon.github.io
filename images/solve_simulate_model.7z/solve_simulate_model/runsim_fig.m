%info=[infidio infsys];
function [ovecnew,arbactivity] = ...
    runsim(numsim,sigidio,sign,sigx,infshare,...
            info,rho,musys,muidio,xbaridio,xbarsys,...
            r,informed,Wzero,numksteps,K,devsim,kcons,numinv,devinfos,...
            numidio,Gamma,arbrate,riskneutralarb,rhoarb)
    
    basis=2;
    %{
    riskneutralarb=1;
    rho=0.05;
    infshare=0.1;
    sign=0.4;
    %}
    altinfo=devinfos;    
    mu=[ones(numidio,1)*muidio;musys];
    fbar=mu;%mean of asset payoffs    
    
    %% this was commented out, uncommenting for now to make a test figure
    %{
    maxarb=xbaridio;arbstep=0.1;
    numiter2=1+maxarb/arbstep;arbs=zeros(numiter2,2);cter=1;
    for activity=0:arbstep:maxarb
        %decrease in the shares of the stocks
        xbaridioa=xbaridio-arbrate*activity;
        numa=numidio+1;
        %xte=zeros(numa,1);zte=zeros(numa,1);
        %calc arbs trading profit
        numsim2=numsim;x=zeros(numa,1);z=zeros(numa,1);
        profits=zeros(numsim2,1);
        for zz=1:numsim2
            %rng(zz)%Fix RNG across sims, can test turning off shocks below
            %[z,x] = drawshocks2(sigidio,sign,sigx,numidio);            
            %p is last output in first row
            [~,~,~,~,zbar,~,~,~,~,~,~,~,...
            ~,~,p0] = ...
                price2(infshare,info,sigx,rho,...
                sigidio,sign,musys,muidio,...
                xbaridio,xbarsys,x,z,r,kcons,numidio,...
                Gamma,xbaridioa);
            %[p p0]
            %{
            arbprofit=zbar(numa)*p(numa)-...
                activity*sum(p(1:numidio));
            %}
            
            arbprofit=zbar(numa)*p0(numa)-...
                activity*sum(p0(1:numidio));        
            %{
            arbprofit0=zbar(numa)*p0(numa)-...
                sum(p0(1:numidio));
            arbprofits=[arbprofit0 arbprofit];
            %}                
            %arbeu=-exp(-rho*arbprofit0); 
            
            %risk neutral
            profits(zz)=arbprofit;
            %risk averse
            %profits(zz)=-exp(-rho*arbprofit);
        end
        
        arbs(cter,:)=[activity mean(profits)];cter=cter+1;
    end
    plot(arbs(:,1),arbs(:,2))
    [~,i]=max(arbs(:,2));
    arbactivity=arbs(i,1);
    xbaridioa=xbaridio-arbrate*arbactivity;
    %}
    
    %test of figure
    %{
    rho=0.15;
    sign=0.25;
    infshare=0.6;
    rhoarb=0.2;
    %}
    maxarb=xbaridio;arbstep=0.1;
    numiter2=1+maxarb/arbstep;
    arbs=zeros(numiter2,4);cter=1;
    for activity=0:arbstep:maxarb
        %decrease in the shares of the stocks
        xbaridioa=xbaridio-arbrate*activity;
        numa=numidio+1;
        %xte=zeros(numa,1);zte=zeros(numa,1);
        %calc arbs trading profit
        %{
        if riskneutralarb==1
            numsim2=1;x=zeros(numa,1);z=zeros(numa,1);
        else
            numsim2=numsim;
        end
        %}
        numsim2=numsim;
        profits=zeros(numsim2,1);
        profits2=zeros(numsim2,1);
        for zz=1:numsim2
            %{
            if riskneutralarb==0
                rng(zz)%Fix RNG across sims, can test turning off shocks below
                [z,x] = drawshocks2(sigidio,sign,sigx,numidio);            
            end
            %}
            rng(zz)%Fix RNG across sims, can test turning off shocks below
            [z,x] = drawshocks2(sigidio,sign,sigx,numidio);            

            %p is last output in first row
            [~,~,~,~,zbar,~,~,~,~,~,~,p,...
            ~,~,p0] = ...
                price2(infshare,info,sigx,rho,...
                sigidio,sign,musys,muidio,...
                xbaridio,xbarsys,x,z,r,kcons,numidio,...
                Gamma,xbaridioa);
            if basis==1
                arbprofit=zbar(numa)*p(numa)-...
                    activity*sum(p(1:numidio)); 
            elseif basis==2
                payoffs=fbar+Gamma*z;
                %zbar
                %{
                zbar(numa)*payoffs(numa)-...
                    activity*sum(payoffs(1:numidio))
                zbar(numa)*p(numa)-...
                    activity*sum(p(1:numidio))
                %}
                arbprofit= -1*(zbar(numa)*payoffs(numa)-...
                    activity*sum(payoffs(1:numidio))) ...
                    + (zbar(numa)*p(numa)-...
                    activity*sum(p(1:numidio)));                 
            end
      
            %risk neutral
            if riskneutralarb==1
                profits(zz)=arbprofit;
            elseif rhoarb==0
                profits(zz)=arbprofit;    
            else
                profits(zz)=-exp(-rhoarb*arbprofit);
            end
            profits2(zz,1)=arbprofit;
        end
        %mean(profits)
        arbs(cter,:)=[activity mean(profits) ...
            mean(profits2) std(profits2)^2];cter=cter+1;
    end
    
    %{
    [~,i]=max(arbs(:,2));
    arbactivity=arbs(i,1);
    arbs(:,5)=arbs(:,3)-((rhoarb)/2)*(arbs(:,4));
    arbs(:,6)=arbs(:,3)-(0.1/2)*(arbs(:,4));
    [~,i2]=max(arbs(:,5));
    arbactivity2=arbs(i2,1);
    [~,i3]=max(arbs(:,6));
    arbactivity3=arbs(i3,1);
    clf
    hold on
    plot(arbs(:,1),arbs(:,2))
    plot(arbs(:,1),arbs(:,5))
    legend('EU','MV')
    arbactivity
    arbactivity2
    arbactivity3
    %}
    %arbs column 1
    %c1 -- activity
    %c2 -- mean risk-adj profits from that activity
    %c3 -- mean profits from that activity
    %c4 -- st. dev. of profits 
    %c5: mean-variance objective 
    arbs(:,5)=arbs(:,3)-((rhoarb)/2)*(arbs(:,4));
    
    %{
    arbs(:,1)=arbs(:,1)/2.5;
    clf
    hold on
    subplot(3,1,1);
    plot(arbs(:,1),arbs(:,3));
    title('E[profit]')
    xlabel('ETF Share') 
    
    subplot(3,1,2);
    plot(arbs(:,1),arbs(:,4));
    title('St. Dev.[profit]')
    xlabel('ETF Share') 
    
    subplot(3,1,3);
    plot(arbs(:,1),arbs(:,5));
    line([0,1],[0,0],'color','red');
    title('MV. Objective')
    xlabel('ETF Share') 
    %}
    [~,i]=max(arbs(:,5));
    arbactivity=arbs(i,1);    
    
    xbaridioa=xbaridio-arbrate*arbactivity;    
    %%fix this number
    infn=10000;
    objfn=zeros(numsim,1);
    objsb=zeros(numsim*infn,2);
    
    %Turns out we don't need to run all the sims to find
    %the arb profits
    %arbs=zeros(numsim,2);
    
    
    %numsim=10000;
    for zz=1:numsim  
 
        rng(zz)%Fix RNG across sims, can test turning off shocks below
        [z,x] = drawshocks2(sigidio,sign,sigx,numidio);

        %zz %display simnum
        
        %% now passing in new xbaridio
        [profitinddev,objs] = ...
            iter(sigidio,sign,sigx,infshare,...
            info,rho,musys,muidio,xbaridio,xbarsys,...
            r,informed,Wzero,numksteps,K,devsim,kcons,z,x,zz,altinfo,...
            numidio,Gamma,activity,xbaridioa);
        
        %new save profits/utilities     
        %}
        
        %% update 6/29: add minus sign
        b=mean(-exp(-rho*(profitinddev)));
        objfn(zz,:)=b;
        
        index1=1+(zz-1)*infn;
        index2=zz*infn;           
        objsb(index1:index2,:)=objs;
        %arbs(zz,:)=arbprofits;
    end %end of simulation loop
    %{
    b=mean(profitsinfdev);
    e=mean(utilitiesinfdev);
    h=rho*mean(profitinddev)-((rho^2)/2)*var(profitinddev);
    j=-1*mean(log(objfn));
    ovecnew=[b e h j];
    %}
    %ovecnew=-1*mean(log(objfn));
    
    %% Mean Variance (has the log)
    ovecnew=mean(rho*objsb(:,1)-((rho^2)/2)*objsb(:,2));
    %% Without the log 
    %(checked against laura's, i think this is wrong)
    %ovecnew=-mean(exp(-rho*objsb(:,1)+((rho^2)/2)*objsb(:,2)));
    %{
    histogram(arbs(:,2))
    mean(arbs(:,2))
    mean(arbs(:,1))
    %}
end

%% here is where we can alter the supply of the ETF
%{
xbaridio
xbarsys
%}
%{
%supply of the risk factors
xbar=[ones(numidio,1)*xbaridio;xbarsys];
%supply of the assets
zbar=(Gamma')\xbar
%total quantity of systematic risk
sum(zbar)

%how many shares the arb converts
activity=1;
%decrease in the shares of the stocks
xbaridioa=xbaridio-arbrate*activity
%this actually doesn't change, as quantity
%of systematic risk doesn't change
xbarsysa=xbarsys
%new supply of risk-factors
xbar=[ones(numidio,1)*xbaridioa;xbarsysa];
%new supply of assets
zbar=(Gamma')\xbar
%total supply of systematic risk after the 
%transformation
sum(zbar)
%}