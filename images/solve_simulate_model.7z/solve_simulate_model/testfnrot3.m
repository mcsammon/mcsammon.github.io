function diff=testfnrot3(Gamma,numidio,kcons,...
                        rotinfo,lstar)
    info1=rotinfo(1);
    info2=rotinfo(2);
    %% Check 1: When everything is diagonal, this is the correct sigma-e
    sigmae=Gamma*diag([ones(numidio,1)*(1/(kcons+info1));...
        (1/(kcons+info2))])*(Gamma');
    defn=sigmae;
    defn=(defn+defn')/2;%have to do this for matlab's sake
    [G,l]=eig(defn); %do decomp
    
    %% sorting of eigenvalues is an issue
    %{ 
    %code from matlab.com
    A = magic(5);
    A=(A+A')/2;
    [V,D] = eig(A)
    [d,ind] = sort(diag(D))
    Ds = D(ind,ind)
    Vs = V(:,ind)
    Vs'*Vs
    %}
    %sort l's eigenvalues
    [~,ind] = sort(diag(l));
    ls = l(ind,ind);
    gs = G(:,ind)  ;
    %sort l stars eigenvalues
    [~,ind] = sort(diag(lstar));
    lstars = lstar(ind,ind);
    %}
    %% check 2; do we satisfy properties of eigen decomposition
    %{
    norm(G*l*G'-defn)
    norm(G'*G-eye(numidio+1))
    norm(gs*ls*gs'-defn)
    norm(gs'*gs-eye(numidio+1))    
    %}
    a=gs*lstars*gs';
    b=sigmae;
    diff=norm(abs(a-b));
end

