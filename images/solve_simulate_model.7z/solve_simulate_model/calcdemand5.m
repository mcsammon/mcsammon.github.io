function [t3,sighatininv,postmeanun,sighatuninv,...
    profitin,profitun,gout,profitind] =...
    calcdemand5(informed,z,Gamma,zz,...
    rhobar,numa,fbar,v,zbar,u,sa,q,a0,a1,a2,p,r,...
    payoffs,supply,numidio,infshare)    

    %% admati demand
    % note: admati model cannot handle all uninformed agents
    %first solve for demand of uninformed
    %% fix 2
    %k=inv(a2)-r*rhobar*q;
    k=(1/rhobar)*(inv(a2)-r*q);
    
    %% fix 3
    %{
    %for gzero
    p1g=eye(numa)-inv((u/q)+rhobar*eye(numa));
    p2g=v\fbar+(q/u)*zbar;
    g0=rhobar*p1g*p2g;
    %}
    g0=a2\a0;
    
    %% adaptation 1
    sat=sa;
    
    %% fix 4, I am moving these calcs up (commented out below)
    g2inf=rhobar*(k+r*inv(sat));
    g2un=rhobar*k;
    
    %% fix 5
    %duninf=rhobar*(g0-k*p);
    duninf=g0-g2un*p;
    
    %% Scale up
    %informed=1000000;
    inftraders=informed;
    
    %signals need to be centered on fbar+Gamma*z -- true payoff
    %plus the noise (Gamma*epsilonj')'
    %% old signal method
    %signals=ones(inftraders,1)*((fbar+Gamma*z)')+(Gamma*epsilonj')';
    %i want to try drawing a second signals and see how things look
    
    %% new signal method
    rng(zz)
    signals=mvnrnd(payoffs,sat,informed);
    g1=rhobar*inv(sat);
    
    % changed above
    %g2=rhobar*(k+r*inv(sa));
    
    %these calculations are also unchanged
    dpt1=ones(inftraders,1)*g0';
    dpt2=(g1*signals')';
    
    %changed to reflect new g2
    %dpt3=ones(inftraders,1)*(g2*p)';
    dpt3=ones(inftraders,1)*(g2inf*p)';
    
    %check that signals integrate to F
    demands=dpt1+dpt2-dpt3;
    %check mc
    
    avgdemand=infshare*mean(demands)+(1-infshare)*duninf';
    [avgdemand' supply]
    %}

    sa=sat;
    numa=numidio+1;
    
    %% Add in B's for posterior means in admati model
    vainf=inv(inv(v)+q*(u\q)+inv(sa));
    vaun=inv(inv(v)+q*(u\q));
    
    %% fix 7
    %{
    b0un=(1/rhobar)*vaun*g0;
    g2un=k;
    b2un=r*eye(numa)-(1/rhobar)*vaun*g2un;
    demandun=rhobar*(vaun\(b0un+(b2un-r*eye(numa))*p));
    b1inf=(1/rhobar)*vainf*g1;
    b0inf=(1/rhobar)*vainf*g0;
    b2inf=r*eye(numa)-(1/rhobar)*vainf*g2;
    %}
    % for uninformed, will need later when computing cost
    b0un=(1/rhobar)*vaun*g0;
    b2un=r*eye(numa)-(1/rhobar)*vaun*g2un;
    
    b1inf=(1/rhobar)*vainf*g1;
    b0inf=(1/rhobar)*vainf*g0;
    b2inf=r*eye(numa)-(1/rhobar)*vainf*g2inf';
    
    %price=((a0+a1*(fbar+Gamma*z)-a2*(zbar+(Gamma')\x)))
    %so unbiased signal about z (not f!) is 
    %sigpnew=(a1*Gamma)\(p-a0-a1*fbar+a2*zbar);
    %% big change: switching to this to avoid numerical issues
    %sighatuninv=inv(v)+q*(u\q);
    
    %now want to match posterior means of informed
    sighatininv=inv(vainf);   
    sighatuninv=inv(vaun);
    ejftildeiadmat=b0inf*ones(1,informed) + ...
        b1inf*signals'+b2inf*p*ones(1,informed);
    t3=ejftildeiadmat';
    postmeanun=b0un+b2un*p;

    payoff=fbar+Gamma*z;
    %mean(demands) is a 1x8, payoff-p*r is a 8x1
    profitin=mean(demands)'.*(payoff-p*r);
    profitind=demands*(payoff-p*r); %d is for detail
    profitun=duninf.*(payoff-p*r);
    gout=[g0 g1 g2inf g2un];
    %{
    %profitind=demands*(payoff-p*r); %d is for detail
    rho=1/rhobar;
    uinformed=-exp(-rho*profitind);
    %{
    mean(profitind)
    size(profitind)  
    %}
    euinformed=mean(uinformed);
    %}
end

