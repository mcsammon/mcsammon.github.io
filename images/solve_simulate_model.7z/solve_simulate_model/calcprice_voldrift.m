%% info=[infidio infsys];
function [rhobar,numa,fbar,v,zbar,u,sa,q,a0,a1,a2,p,...
    Gamma,payoffs,supply,p0,xbar] = ...
        calcprice_voldrift(infshare,info,sigx,rho,...
        sigidio,sign,musys,muidio,...
        xbaridio,xbarsys,x,z,r,kcons,numidio)

    %% easier fix...
    info=info+kcons; 
    
    p1=eye(numidio+1);
    p2=[zeros(numidio+1,numidio) ones(numidio+1,1)];
    Gamma=p1+p2;Gamma(numidio+1,numidio+1)=1;

    mu=[ones(numidio,1)*muidio;musys];
    xbar=[ones(numidio,1)*xbaridio;xbarsys];
    
    %% admati prices
    rhobar=1/rho;%avg. risk aversion
    numa=numidio+1;%number of assets
    fbar=mu;%mean of asset payoffs
    
    v=Gamma*diag([ones(numidio,1)*sigidio;sign])*(Gamma');%asset payoff variance, need to rotate
    %asset supply variance
    zbar=(Gamma')\xbar;
    u=((Gamma')\(sigx*eye(numa)))*inv(Gamma')';
    
    %avg. learning 
    sa=Gamma*diag([ones(numidio,1)*(1/info(1));...
        (1/info(2))])*(Gamma');
    
    %% adaptation for this code
    %need to scale by % informed
    supply=zbar+(Gamma')\x;
    payoffs=fbar+Gamma*z;
    vt=v;ut=u;sat=sa;zbart=zbar;fbart=fbar;
    vt(end,:) = [];
    vt(:,end) = [];
    ut(end,:) = [];
    ut(:,end) = [];
    sat(end,:) = [];
    sat(:,end) = [];  
    zbart(end) = [];
    fbart(end) = [];
    numat=2;
    supply(end)=[];
    payoffs(end)=[];
    
    %want to return full matricies, so just put in t's
    q=rhobar*infshare*inv(sat);

    pt1=rhobar*inv(vt)+rhobar*q*(ut\q)+q;
    pt2=(vt\fbart)+q*(ut\zbart);
    pt3=(q+rhobar*q*(ut\q));
    pt4=eye(numidio)+rhobar*(q/ut);
    a0=(rhobar/r)*(pt1\pt2);
    a1=(1/r)*(pt1\pt3);
    a2=(1/r)*(pt1\pt4);
    p=a0+a1*payoffs-a2*supply;
    p0=((a0+a1*(fbart)-a2*(zbart)));
end

