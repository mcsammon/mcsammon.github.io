%info=[infidio infsys];
function [outmat] = ...
    masterrunsim_voldrift2(numsim,sigidio,sign,sigx,infshare,...
            info,rho,musys,muidio,xbaridio,xbarsys,...
            r,informed,Wzero,numksteps,K,devsim,kcons,numinv,devinfos,...
            numidio)
    
    altinfo=devinfos;
    %want a way to store prices, volumes and turnovers
    numa=numidio+1;
    nument=numa*numsim;
    outmat=zeros(nument,12);
    for zz=1:numsim  
 
        rng(zz)%Fix RNG across sims, can test turning off shocks below
        [z,x] = drawshocks2(sigidio,sign,sigx,numidio);

        %zz %display simnum
        %start from runsimfast3
        [price0,price1,price2,turn,vol] = ...
            runsimfast_voldrift2(sigidio,sign,sigx,infshare,...
            info,rho,musys,muidio,xbaridio,xbarsys,...
            r,informed,Wzero,numksteps,K,devsim,kcons,z,x,zz,altinfo,...
            numidio);
        index1=1+(zz-1)*numa;
        index2=zz*numa;
        simcol=zz*ones(numa,1);
        addrows=[simcol price0 price1 price2 turn vol];
        outmat(index1:index2,:)=addrows;
    end %end of simulation loop
end

