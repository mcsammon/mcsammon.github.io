%% info=[infidio infsys];
function [alteu] = testfnsymf(infshare,info,rho,sigx,sign,sigidio,...
    xbaridio,xbarsys,kcons,numsim,musys,muidio,r,informed,Wzero,numksteps,...
    K,devsim,numinv,devinfos,numidio,Gamma)
        %{
        info 
        devinfos
        %}
        %% program 3, master run sim
        [pms,postpres,postpresdeva,pmsdeva,pmsun,postpresun,...
    profits3,gout,ncmat,ovecnew] = ...
    masterrunsimf(numsim,sigidio,sign,sigx,infshare,...
            info,rho,musys,muidio,xbaridio,xbarsys,...
            r,informed,Wzero,numksteps,K,devsim,kcons,numinv,devinfos,...
            numidio,Gamma);
            
        %% program 4, calculate deviation utility
        
        [actual,alt]=finaleu4(pms,postpres,r,Wzero,info,...
            postpresdeva,pmsdeva,devinfos);
        %4th post is veldkamp, 5th pos is admati
        %alt=[altinfo' eui2 euiadmat lams]
        %% Old Method (mean)
        %alteu=alt(3);
        %% New method (EU)
        %alteu=ovecnew(5); 
        %alteu=ovecnew(4); 
        %% New method (MV)
        %alteu=ovecnew(8); 
        %% New method (log eu)
        alteu=ovecnew(11); 
        
        %add in uninformed
        v=cov(pmsun);%calculate vcv of posterior means
        t1=postpresun*v;t2=0.5*trace(t1);
        mp=mean(pmsun);
        t3=0.5*mp*postpresun*mp';
        euiun=r*Wzero+t2+t3;%ex-ante expected utility 
        %test
        %{
        alteu
        actual(3)
        euiun
        %}

end

