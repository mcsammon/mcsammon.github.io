    %% Set Parameters
clc;clear;rng(1)

musys=15;muidio=15; %Set mean payoffs
sigidio=0.55; %set vol of idiosyncratic risk
sigx=0.5;%variance of noise
r=1;%risk free, turn off for now
Wzero=0;%initial wealth
K=1;

kcons=0.001;%v1
%kcons=0.0001;%v2

%for testing mc need a lot more investors to overcome simulation noise
numinv=100000;
%numinv=1000000;
toler=0.02; %tolerance for solution finding
tol=0.001; %tolerance for numerical method on laura sols
pdifftol=0.0005;%tol for numerical method on marco sols

%numsim=10000;
%numsim=5000;
numsim=2000; %save time, not trying to solve anything...
%numsim=1000;
%numsim=2; %for checking data writing

devsim=numsim;%number of deviation simulations

%going to argue that there is just a hard cap at 8 assets

minassets=2;maxassets=8;%max possible idio assets

%tsupplyidio=8; %fix total supply of idiosyncratic assets
%there is something weird about varying the total supply of idio assets
%it interacts somehow with risk aversion, so they should be intertwined
tsupplyidio=20;
arbrate=1;

%% main code (i.e. params already set)
%alpha=0.001
Mtemp=csvread('calibration_endetf_finer_tgt15.csv');
%[numsave,~]=size(Mtemp)
numsave=33
savemat=zeros(numsave,26);
s0='C:\Users\mcsam\Dropbox\EarningsDayVol\sim\noute2\';
newcter=0;
%#loop over parameters
for al=1:1
    if al==1
        kcons=0.001;
    elseif al==2
        kcons=0.05;
    end
for ral=1:10    
    %rhoarb=0.05+0.05*(ral-1); %risk aversion of arbatrageur
    %rhoarb=0.5;
    %rhoarb=ral;
    rhoarb=0.1*(ral-1);
for rholoop= 1:1
    %rho=0.4
    rho=0.15;
    for signloop=1:1
        sign=0.3;
        %.25-.35
        for infloop=1:3
           infshare=0.2+0.05*infloop;
             for numidiol=4:4
                 numidio=numidiol*2;
[kcons rho sign infshare numidio rhoarb]    
newcter=newcter+1;

%% Main Code for Solving                
%make the # k steps depend on # assets
%so increment in K is same...
numksteps=50*numidio;%in 2 case it is 100 x 100
stepsize=K/numksteps;
xbaridio=tsupplyidio/numidio;
xbarsys=xbaridio*numidio; 
informed=round(infshare*numinv);

%% Want Gamma to become an input computed outside the price
% function, rather than created inside, can apply to 
% many other model/param specific pieces 
%% beta=0
%{
Gamma=eye(numidio+1);
%}
%% beta=1

p1=eye(numidio+1);
p2=[zeros(numidio+1,numidio) ones(numidio+1,1)];
Gamma=p1+p2;Gamma(numidio+1,numidio+1)=1;
%}
%% Could add more basic calculations like U, V here
altinfo=Mtemp(newcter,3:4);
trueinfo=Mtemp(newcter,3:4);
arbactivity=Mtemp(newcter,11);
xbaridioa=xbaridio-arbrate*arbactivity;   

%% This is very time consuming, but need to compute cost of informed
[postpres,postpresun,gout,ncmat,ovecnew,...
    pvecin,pvecout,addout] = ...
    run8(numsim,sigidio,sign,sigx,infshare,...
            altinfo,rho,musys,muidio,xbaridioa,xbarsys,...
            r,informed,Wzero,numksteps,K,kcons,numinv,...
            numidio,Gamma); %change to xbaridioa
%newcter=newcter+1; %moved
%% baseline
savemat(newcter,1:8)=[trueinfo,altinfo,rho,sign,infshare,numidio];
%% addon 
savemat(newcter,9:24)=[ncmat,ovecnew,addout];
%% add details of rhoarb and supply
savemat(newcter,25:26)=[rhoarb,arbactivity];

%% additional outputs
s1=num2str(sign);
s2=num2str(rho);
s3=num2str(infshare);
s4=num2str(numidio);
s5=num2str(kcons);
s6=num2str(rhoarb);
%{
%% output precisions
presmat=[postpres postpresun];
outname2=strcat(s0,'precv2',s1,s2,s3,s4,s5,s6,'.csv');
csvwrite(outname2,presmat)   

%% output parts of demand function
outname3=strcat(s0,'goutv2',s1,s2,s3,s4,s5,s6,'.csv');
csvwrite(outname3,gout)  

%% output profits by asset 
profitsbyaout=[pvecin pvecout];
outname4=strcat(s0,'pibyav2',s1,s2,s3,s4,s5,s6,'.csv');
csvwrite(outname3,profitsbyaout) 

%% output profits by asset and demand function 
%gout=[g0 g1 g2inf g2un];
combine=[pvecin' pvecout' gout postpres postpresun];
outname5=strcat(s0,'combinelav2',s1,s2,s3,s4,s5,s6,'.csv');
csvwrite(outname5,combine) 
%}
%% additional simulations
%add more sim
s1=num2str(sign);
s2=num2str(rho);
s3=num2str(infshare);
s4=num2str(numidio);
s5=num2str(kcons);
s6=num2str(rhoarb);
%numsimb=10000;
%numsimb=2000;%save time
numsimb=numsim;
outmatt = ...
        masterrunsim_voldrift2(numsimb,sigidio,sign,sigx,infshare,...
        altinfo,rho,musys,muidio,xbaridioa,xbarsys,...
        r,informed,Wzero,numksteps,K,numsimb,kcons,numinv,altinfo,...
        numidio); %alt info is in both places 
        %%Also change to xbaridioa
        
%need to not have the +1 b/c we don't have the ETF
%nument=(numidio+1)*numsim;
nument=(numidio+1)*numsimb;
trow=ones(nument,1)*[rho,sign,infshare,numidio];
outmatt2=[trow outmatt];
outname=strcat(s0,'voldrift_lav2_tgt15',s1,s2,s3,s4,s5,s6,'.csv');
csvwrite(outname,outmatt2)  
%}
            end %end of # assets loop
        end %end of share informed loop
 
    end %end of sign loop
    %periodically save     
    csvwrite('calibration_endetf_finer_tgt15_sim.csv',savemat)
end %end of rholoop
end %end of kcons loop
end %end of etf arb risk aversion loop
csvwrite('calibration_endetf_finer_tgt15_sim.csv',savemat)