%% match lauras
tic;clc;clear;rng(1)
musys=15;
muidio=15;
sigidio=0.55;
beta=1;
numidio=2;
numa=numidio+1;
%laura setup
%xbaridio=1;xbarsys=15;

xbaridio=2;
xbarsys=xbaridio*numidio; 
sigx=0.5;%variance of noise
r=1.01;%risk free
Wzero=220;%initial wealth
K=1;kcons=0.05;%setting k cons to zero brings us back to the basic model
% need to go through and check kcons...

numinv=10000;
%numinv=5000; %set # investors, i added more
toler=0.02; %tolerance for solution finding
tol=0.001;

numsim=500;
%numsim=2;
numksteps=200;%does having more steps help? very slightly
devsim=numsim;%number of deviation simulations

%rotation
p1=eye(numa);
p2=[zeros(numidio+1,numidio) ones(numa,1)];
Gamma=p1+p2;Gamma(numa,numa)=1;
rfsupplies=[xbaridio*ones(numidio,1);xbarsys];
%asset supplies (not risk factor supplies)
assetsupplies=(Gamma')\rfsupplies;
%}
numinfs=1; %# of possible information choices
paramsets=4;
numsave=paramsets*numinfs; %# of saved entries
savemat=zeros(numsave,10);

for recession=1:4
%for recession=1:6
    disp('paramset')
    recession
    %parameter sets 
    if recession==1
        sign=0.25; rho=0.175;
    elseif recession==2
        sign=0.5; rho=0.175;
    elseif recession==3
        sign=0.25; rho=0.35; 
    elseif recession==4
        sign=0.5; rho=0.35;
    end
for infloop=1:numinfs
    %for infloop=1:19
    %infshare=0.05*infloop;
    infshare=0.2;
    informed=round(infshare*numinv);
    solmat=find_solutionssym(sign,rho,sigidio,xbaridio,...
        xbarsys,sigx,K,infshare,toler,numksteps,kcons,numidio);
    infsys=solmat(4);infidio=solmat(3);
    trueinfo=[infidio infsys]
    
%{
end
end
%}
    disp('iterate')
    %%let's start out at some suboptimal info
    %i am speeding up here to save some steps
    altinfo=[(K/2)/numidio,K/2];
    
    zkz=1;breakcode=0;
    %keep track of oscilation
    movehist=zeros(100,1);
    while breakcode==0
        zkz
        %% need to define a new fn2.  Currently, fn2 takes info, and a possible 
        %deviation info as an input, and returns your expected utility
        
        %this should be defined with respect to ALTINFO
        %in second argument, not 'info' i.e. right info.
        %why? 
        %need to check deviations relative to 
        %everyone being at alt info
        
        %{
        testfnsym(infshare,altinfo,rho,sigx,sign,sigidio,...
        xbaridio,xbarsys,kcons,numsim,musys,muidio,r,informed,Wzero,numksteps,...
        K,devsim,numinv,devinfos,numidio)
        disp('test')
        %}
        %again, needs to be defined with respect to alt info
        fn2=@(devinfos) testfnsym(infshare,altinfo,rho,sigx,sign,sigidio,...
        xbaridio,xbarsys,kcons,numsim,musys,muidio,r,informed,Wzero,numksteps,...
        K,devsim,numinv,devinfos,numidio);
        %fn2(altinfo)
        
        %so fn2 computes  your expected utility, conditional on everyone being
        %at 'altinfo'
        %now, rather than compute entire grid, just compute
        %two directions: inc learn 1 and learn 2, 
        %dec learn 1 and learn 2
        stepsize=K/numksteps;
        %need to move on grid, right now altinfo has order 
        %info=[infidio infsys];
        base=fn2(altinfo);
        aup=altinfo+[stepsize,-numidio*stepsize];
        adown=altinfo-[stepsize,-numidio*stepsize];
        up=fn2(aup);%more on 1 and 2
        down=fn2(adown);
        %[base up down]
        altinfoold=altinfo
        if up>base && down>base
            disp('error')
            move=4;
        elseif up>base && down<base
            altinfo=aup;
            move=1;
        elseif down>base && up<base
            altinfo=adown;
            move=2;
        else%exactly equal, should not happen
            breakcode=1;
            move=3;
        end
        
        movehist(zkz)=move;

        % save actual utility
        actualeu=fn2(altinfoold);
        %compare to best deviation
        deveu=fn2(altinfo);
        %% how much we are improving?
        %eventually could add stop based on this
        inceu=deveu-actualeu;
        
        
        %% need to write a stopping when would go to edge of grid...
        edge1=altinfo(1)+stepsize;
        %3 moves in steps of 2
        edge3=altinfo(2)+numidio*stepsize;
        %need to think about 5050 edge as well
        if abs(edge3-K)<tol && move==2
            disp('edge3')
            altinfo=[zeros(numidio,1);K]';
            breakcode=1;
        elseif abs(edge1-K/numidio)<tol && ...
                move==1
            disp('edge 1 and 2')
            altinfo=[ones(numidio,1)*K/numidio;0]';
            breakcode=1;
        end
        
        if(min(altinfo))<0
            disp('goneg')
            if altinfo(2)>altinfo(1) 
                altinfo=[zeros(numidio,1);K]';
            else
                altinfo=[ones(numidio,1)*K/numidio;0]';
            end
            breakcode=1;
        end
        if zkz>=5
           if movehist(zkz)==movehist(zkz-2) && ...
                   movehist(zkz)==movehist(zkz-4) && ...
                   movehist(zkz)~=movehist(zkz-1)      
               disp('osc')
               altinfo
               altinfoold
               breakcode=1;
           end
        end
        zkz=zkz+1;
        if zkz==100 %size of movehist
            disp('slow')
            breakcode=1;
        end
        %negative gradient would suggest to decrease info1 and info2
        %for symmetric case, just try moving to edge of grid in each direction?
    end
    %{
    rng(1)%fix rng for calculating cost of becoming informed
    infocost=costinformed(sigmai1,infshare,...
            trueinfo,rho,sigx,sigmai2,sign,xbar1,xbar2,xbar3,kcons,...
            numsim,b1,b2,mu1,mu2,mu3,r,informed,Wzero,numksteps,K,devsim,...
            numinv,shockson,trueinfo,usemed);
    savemat(infloop+numinfs*(recession-1),1:10)=...
        [trueinfo,altinfo,infocost,infshare,rho,sign];
    %}
    savemat(infloop+numinfs*(recession-1),1:7)=...
        [trueinfo,altinfo,infshare,rho,sign];    
end
end
savemat
%}