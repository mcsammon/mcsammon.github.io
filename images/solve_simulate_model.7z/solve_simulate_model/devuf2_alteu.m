function [profitind,objs] = devuf2_alteu(z,Gamma,informed,...
    altinfo,rhobar,numa,fbar,v,u,q,a0,a2,p,r,kcons,numidio,...
    payoffs,zz)
    
    %% need to apply all fixes in calcdemand2 to devu3
    %% admati
    %Gamma*diag([1/altinfo(1) 1/altinfo(2) 1/altinfo(3)])*Gamma'
    %so we need to update sa here
    altinfo=altinfo+kcons;
    sa=Gamma*diag([ones(numidio,1)*(1/altinfo(1));...
        (1/altinfo(2))])*(Gamma');
    %again, not returned so can do this directly
 
    %new method for defining sa above
    %sa=Gamma*diag([1/altinfo(1) 1/altinfo(2) 1/altinfo(3)])*Gamma';
    
    %% fix 2, typo in K
    %k=inv(a2)-r*rhobar*q;
    k=(1/rhobar)*(inv(a2)-r*q);

    %% fix 3 -- use 'correct' a's to fix g0
    %{
    p1g=eye(numa)-inv((u/q)+rhobar*eye(numa));
    p2g=v\fbar+(q/u)*zbar;
    g0=rhobar*p1g*p2g;
    %}
    g0=a2\a0;
    
    %SCALE UP
    informed=10000;
    %informed=informed*100000;
    inftraders=informed;
    
    %% old signal method
    %recall: epsilonj=mvnrnd(zeros(3,1),diag(sigetaj),informed);
    %signals=ones(inftraders,1)*((fbar+Gamma*z)')+(Gamma*epsilonj')';
    %i want to try drawing a second signals and see how things look
    
    %% new signal method -- want to add a mini loop in here for this?
    rng(zz)
    %rng(1);
    signals=mvnrnd(payoffs,sa,informed);

    %% fix 4, note, don't need to care about uninformed in devu
    g2inf=rhobar*(k+r*inv(sa)); %just had to fix k
    g1=rhobar*inv(sa); %unchanged
    %g2=rhobar*(k+r*inv(sa));% so this didn't actually change
    
    payoff=fbar+Gamma*z;
    dpt1=ones(inftraders,1)*g0';
    dpt2=(g1*signals')';
    
    %changed to reflect new g2
    %dpt3=ones(inftraders,1)*(g2*p)';
    dpt3=ones(inftraders,1)*(g2inf*p)';
    
    %check that signals integrate to F
    demands=dpt1+dpt2-dpt3;
    %{
    g2inf=rhobar*(k+r*inv(sat));
    g2un=rhobar*k;    
    duninf=g0-g2un*p;
    %}
    profitind=demands*(payoff-p*r); %d is for detail
    
    %% now want to add conditional thing
    vainf=inv(inv(v)+q*(u\q)+inv(sa));
    %vainf is the conditional variance
    b1inf=(1/rhobar)*vainf*g1;
    b0inf=(1/rhobar)*vainf*g0;
    b2inf=r*eye(numa)-(1/rhobar)*vainf*g2inf';
    %now want to match posterior means of informed
    sighatininv=inv(vainf);   
    ejftildeiadmat=b0inf*ones(1,informed) + ...
        b1inf*signals'+b2inf*p*ones(1,informed);
    
 
    %rho=1/rhobar;
    %{
    tic
    objs=zeros(informed,2);
    for c=1:informed
        ew=demands(c,:)*(ejftildeiadmat(c,:)'-p*r);
        ev=demands(c,:)*vainf*demands(c,:)';      
        objs(c,:)=[ew,ev];
        %objs(c)=rho*ew-((rho^2)/2)*ev;        
    end    
    toc
    %}
    
    %way faster
    ejftildeiadmat=ejftildeiadmat';
    ew=demands.*(ejftildeiadmat-(p*r)');
    ev=(demands*vainf).*demands;
    objs=[sum(ew,2) sum(ev,2)];
    %}
    %comp=[objs objs2 objs(:,1)-objs2(:,1) objs(:,2)-objs2(:,2)];
end

