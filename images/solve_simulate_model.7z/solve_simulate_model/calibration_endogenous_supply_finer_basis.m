%% Set Parameters
tic;clc;clear;rng(1)

musys=15;muidio=15; %Set mean payoffs
sigidio=0.55; %set vol of idiosyncratic risk
sigx=0.5;%variance of noise
r=1;%risk free, turn off for now
Wzero=0;%initial wealth
K=1;
arbrate=1;
%riskneutralarb=1;
riskneutralarb=0;

%% Do we want to re-solve for kcons=0.0001?
%eventually
%kcons=0.0001; %v2
kcons=0.001;%v1
%kcons=0.05;
%for testing mc need a lot more investors to overcome simulation noise
numinv=100000;
%numinv=10000;
toler=0.02; %tolerance for solution finding
tol=0.001; %tolerance for numerical method on laura sols
pdifftol=0.0005;%tol for numerical method on marco sols

numsim=1000; %for actually solving the model
%numsim=2; %for checking data writing

devsim=numsim;%number of deviation simulations

%going to argue that there is just a hard cap at 8 assets
%minassets=2;maxassets=8;%max possible idio assets
%tsupplyidio=8; %fix total supply of idiosyncratic assets
%there is something weird about varying the total supply of idio assets
%it interacts somehow with risk aversion, so they should be intertwined
tsupplyidio=20;
%tsupplyidio=40;

numinfs=16; %# of possible information choices on the grid, for now
%this will go from 0.05 to 0.50 -- model cannot accomodate 0 informed

%need to say how many obs we are saving, but this will be a grid now
numrhos=10;numsigns=9;numral=10;
paramsets=numrhos*numsigns*numral; %how many different parameters will we try

%% main code (i.e. params already set)
%numsave=paramsets*numinfs*(maxassets-minassets+1);
%numsave=paramsets*8*1*2
numsave=paramsets*18*1*1 %no second kcons
%18 is for infloop, 1 is for assets (saving time)
%1 is forkcons

savemat=zeros(numsave,14);

newcter=0;
%loop over: rho, sign, infshare, kcons i.e. alpha and #assets
%add new loop -- ETF arb risk aversion

for al=1:1
    if al==1
        kcons=0.001;
    elseif al==2
        kcons=0.05;
    end
for ral=1:10    
    %rhoarb=0.05+0.05*(ral-1); %risk aversion of arbatrageur
    %rhoarb=0.5;
    %rhoarb=ral;
    if ral==1
        rhoarb=0;
    elseif ral==2
        rhoarb=1;
    elseif ral>2
        rhoarb=ral^2;
    end
%% this code was sloppy, we can reorganize it
%{
for rholoop=1:5    
    rho=0.05+0.1*(rholoop-1);
    for signloop=1:5
           sign=0.05+0.1*(signloop-1);    
        for infloop=1:6
            infshare=0.1*infloop+0.1;
%}            
for rholoop= 1:10
    rho=0.05+0.05*(rholoop-1);
    for signloop=1:9
        sign=0.05+0.05*(signloop-1);
        for infloop=1:18
           infshare=0.05*infloop;
             for numidiol=4:4
                 numidio=numidiol*2;
[kcons rho sign infshare numidio]    
errcode=0;
%% Main Code for Solving                
%make the # k steps depend on # assets
%so increment in K is same...
%numksteps=100;
numksteps=50*numidio;%in 2 case it is 100 x 100
stepsize=K/numksteps;
xbaridio=tsupplyidio/numidio;
xbarsys=xbaridio*numidio; 
informed=round(infshare*numinv);

%% beta=0
%{
Gamma=eye(numidio+1);
%}

%% beta=1

p1=eye(numidio+1);
p2=[zeros(numidio+1,numidio) ones(numidio+1,1)];
Gamma=p1+p2;Gamma(numidio+1,numidio+1)=1;
%}

v=Gamma*diag([ones(numidio,1)*sigidio;sign])*(Gamma');
vhalf=sqrtm(v); %adj for diagonal gamma

%In the paper, they solve the model with var(f tilde)=
%some diagonal matrix.  But in the appendix, they require
%that var(f)=I, which would also require rotating the
%asset supplies and asset supply variances

%% Solve the orthogonal version of the model 
solmat=find_solutionssym(sign,rho,sigidio,xbaridio,...
    xbarsys,sigx,K,infshare,toler,numksteps,kcons,numidio);
infsys=solmat(4);infidio=solmat(3);
trueinfo=[infidio infsys];
%[sign rho infshare numidio trueinfo]

%% found a solution (can save time starting close)
if trueinfo(1)>=0 && trueinfo(2)>=0
    %% need to make sure we don't start on edge
    if (trueinfo(2)-2*numidio*stepsize)<=0 %%all on 1, take two steps away
    	altinfo=trueinfo-2*[stepsize,-numidio*stepsize];
    elseif (trueinfo(2)+2*numidio*stepsize)>=1 %% all on 2, take two steps away
        altinfo=trueinfo+2*[stepsize,-numidio*stepsize];
    else
        altinfo=trueinfo;
    end
    
else
    %if no solution 
    altinfo=[(K/2)/numidio,K/2];
end
%}

%% start in middle, not needed, just dont start on edge
%altinfo=[(K/2)/numidio,K/2];
%altinfo=[0,1];

zkz=1;breakcode=0;
%keep track of oscilation
movehist=zeros(100,1);

%% Numerical Solution
altinfo
%working, so this is back on
while breakcode==0
    zkz
    
    %again, needs to be defined with respect to alt info
    %% faster fn
    fn2=@(devinfos) symr(infshare,altinfo,rho,sigx,sign,sigidio,...
    xbaridio,xbarsys,kcons,numsim,musys,muidio,r,informed,Wzero,numksteps,...
    K,devsim,numinv,devinfos,numidio,Gamma,arbrate,...
    riskneutralarb,rhoarb);
    %fn2(altinfo)
    
    %% Check; does gamma matter/ yes
    %{
    fn3=@(devinfos) testfnsymf2(infshare,altinfo,rho,sigx,sign,sigidio,...
    xbaridio,xbarsys,kcons,numsim,musys,muidio,r,informed,Wzero,numksteps,...
    K,devsim,numinv,devinfos,numidio,eye(numidio+1));
    fn3(altinfo) 
   %}
    %so fn2 computes  your expected utility, conditional on everyone being
    %at 'altinfo'
    %now, rather than compute entire grid, just compute
    %two directions: inc learn 1 and learn 2, 
    %dec learn 1 and learn 2
    
    %need to move on grid, right now altinfo has order 
    %info=[infidio infsys];
   
    base=fn2(altinfo);
    aup=altinfo+[stepsize,-numidio*stepsize];
    adown=altinfo-[stepsize,-numidio*stepsize];
    up=fn2(aup);%more on 1 and 2
    down=fn2(adown);
    altinfoold=altinfo;
    if up>base && down>base
        %disp('error')
        errcode=1;
        breakcode=1;
        move=4;
    elseif up>base && down<base
        altinfo=aup;
        move=1;
    elseif down>base && up<base
        altinfo=adown;
        move=2;
    else%exactly equal, or base greater
        breakcode=1;
        move=3;
    end
    %maybe set a threshold where things are so close 
    %that maybe we stop moving?
    %[up base down move up-base down-base]
    pdiff1=abs((up-base)/base);
    pdiff2=abs((down-base)/base);
    %[up base down up-base down-base pdiff1 pdiff2]
    %[100*log(base) 100*log(up) 100*log(down) move]
    
    movehist(zkz)=move;
    %i was able to save 2 functin evals each loop

    %% need to write a stopping when would go to edge of grid...
    edge1=altinfo(1)+stepsize;
    %3 moves in steps of 2
    edge3=altinfo(2)+numidio*stepsize;
    %need to think about 5050 edge as well
    %{
    if abs(edge3-K)<tol && move==2
        disp('edge3')
        altinfo=[0;K]';
        breakcode=1;
    elseif abs(edge1-K/numidio)<tol && move==1
        disp('edge 1 and 2')
        altinfo=[K/numidio;0]';
        breakcode=1;
    end
    %}
    %are we going to hit an edge?
    if edge3>K && move==2
        disp('edge3')
        altinfo=[0;K]';
        breakcode=1;
    elseif edge1>(K/numidio) && move==1
        disp('edge 1 and 2')
        altinfo=[K/numidio;0]';
        breakcode=1;
    end
    %}
    
    if(min(altinfo))<0
        disp('goneg')
        if altinfo(2)>altinfo(1) 
            altinfo=[0;K]';
        else
            altinfo=[K/numidio;0]';
        end
        breakcode=1;
    end
    %shorter osc def
    if zkz>=3
       if movehist(zkz)==movehist(zkz-2) && ...
               movehist(zkz)~=movehist(zkz-1)      
           disp('osc2')
           breakcode=1;
           %set to last one i.e. before last oscilation?
           %altinfo=altinfoold;
       end
    end
    
    zkz=zkz+1;
    %how slow is slow?
    if zkz==numksteps %size of movehist
        disp('slow')
        breakcode=1;
    end
end

%% actual code
basis=2;
mu=[ones(numidio,1)*muidio;musys];
fbar=mu;%mean of asset payoffs   

maxarb=xbaridio;arbstep=0.1;
numiter2=1+maxarb/arbstep;
arbs=zeros(numiter2,4);cter=1;
for activity=0:arbstep:maxarb
    %decrease in the shares of the stocks
    xbaridioa=xbaridio-arbrate*activity;
    numa=numidio+1;
    %xte=zeros(numa,1);zte=zeros(numa,1);
    %calc arbs trading profit
    numsim2=numsim;
    profits=zeros(numsim2,1);
    profits2=zeros(numsim2,1);
    for zz=1:numsim2
        rng(zz)%Fix RNG across sims, can test turning off shocks below
        [z,x] = drawshocks2(sigidio,sign,sigx,numidio);            

        %p is last output in first row
        [~,~,~,~,zbar,~,~,~,~,~,~,p,...
        ~,~,p0] = ...
            price2(infshare,altinfo,sigx,rho,...
            sigidio,sign,musys,muidio,...
            xbaridio,xbarsys,x,z,r,kcons,numidio,...
            Gamma,xbaridioa);
        if basis==1
            arbprofit=zbar(numa)*p(numa)-...
                activity*sum(p(1:numidio)); 
        elseif basis==2
            payoffs=fbar+Gamma*z;
            arbprofit= -1*(zbar(numa)*payoffs(numa)-...
                activity*sum(payoffs(1:numidio))) ...
                + (zbar(numa)*p(numa)-...
                activity*sum(p(1:numidio)));                 
        end

        %risk neutral
        if riskneutralarb==1
            profits(zz)=arbprofit;
        elseif rhoarb==0
            profits(zz)=arbprofit;    
        else
            profits(zz)=-exp(-rhoarb*arbprofit);
        end
        profits2(zz,1)=arbprofit;
    end
    %mean(profits)
    arbs(cter,:)=[activity mean(profits) ...
        mean(profits2) std(profits2)^2];cter=cter+1;
end
arbs(:,5)=arbs(:,3)-((rhoarb)/2)*(arbs(:,4));
[~,i]=max(arbs(:,5));
arbactivity=arbs(i,1); 

xbaridioa=xbaridio-arbrate*arbactivity;
  
%finfo %from rotated solution
newcter=newcter+1;
savemat(newcter,1:14)=[trueinfo,altinfo,rho,sign,infshare,numidio,...
    errcode,kcons,arbactivity,riskneutralarb,rhoarb,tsupplyidio];
                   
            end %end of # assets loop
        end %end of share informed loop
%save periodically
csvwrite('calibration_endetf_finer.csv',savemat)
    end %end of sign loop
end %end of rholoop
end
end
